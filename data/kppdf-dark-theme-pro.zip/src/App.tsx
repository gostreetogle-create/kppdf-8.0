import React, { useState } from 'react';
import { MainTab, ThemeStyle, AccentColor } from './types';
import { Header } from './components/Header';
import { ThemeComparisonBanner } from './components/ThemeComparisonBanner';
import { GanttView } from './components/views/GanttView';
import { ProcurementView } from './components/views/ProcurementView';
import { WarehouseView } from './components/views/WarehouseView';
import { CustomersView } from './components/views/CustomersView';
import { RegistersView } from './components/views/RegistersView';
import { DocumentStudioView } from './components/views/DocumentStudioView';
import { WorkTypesModal } from './components/views/WorkTypesModal';
import { DevPromptModal } from './components/DevPromptModal';
import { PaletteTokensModal } from './components/PaletteTokensModal';
import { Briefcase, ShieldCheck, CheckCircle2, Sliders, Database, Cpu } from 'lucide-react';

export function App() {
  const [currentTab, setCurrentTab] = useState<MainTab>('workshop');
  const [themeStyle, setThemeStyle] = useState<ThemeStyle>('modern');
  const [accent, setAccent] = useState<AccentColor>('amber');

  // Modals state
  const [isWorkModalOpen, setIsWorkModalOpen] = useState(false);
  const [isPromptModalOpen, setIsPromptModalOpen] = useState(false);
  const [isPaletteModalOpen, setIsPaletteModalOpen] = useState(false);

  const isModern = themeStyle === 'modern';

  return (
    <div 
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
        isModern ? 'bg-[#0c0e14] text-slate-100' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      {/* Top Application Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        themeStyle={themeStyle}
        onToggleThemeStyle={setThemeStyle}
        accent={accent}
        onChangeAccent={setAccent}
        onOpenWorkModal={() => setIsWorkModalOpen(true)}
        onOpenPromptModal={() => setIsPromptModalOpen(true)}
        onOpenPaletteModal={() => setIsPaletteModalOpen(true)}
      />

      {/* Comparison & Audit Banner */}
      <ThemeComparisonBanner
        themeStyle={themeStyle}
        onToggleThemeStyle={setThemeStyle}
        accent={accent}
        onOpenPrompt={() => setIsPromptModalOpen(true)}
      />

      {/* Dynamic Main View */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {currentTab === 'workshop' && (
          <GanttView themeStyle={themeStyle} accent={accent} />
        )}

        {currentTab === 'procurement' && (
          <ProcurementView themeStyle={themeStyle} accent={accent} />
        )}

        {currentTab === 'warehouse' && (
          <WarehouseView themeStyle={themeStyle} accent={accent} />
        )}

        {currentTab === 'clients' && (
          <CustomersView themeStyle={themeStyle} accent={accent} />
        )}

        {currentTab === 'registers' && (
          <RegistersView themeStyle={themeStyle} accent={accent} />
        )}

        {currentTab === 'documents' && (
          <DocumentStudioView themeStyle={themeStyle} accent={accent} />
        )}

        {/* Deals view */}
        {currentTab === 'deals' && (
          <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center justify-center text-center">
            <div className={`p-4 rounded-full mb-3 ${isModern ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
              <Briefcase className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold text-white mb-1">Сделки и заказы клиентов</h2>
            <p className="text-xs text-slate-400 max-w-md mb-4">
              Воронка заказов и договоров синхронизирована с графиком цеха и снабжением.
            </p>
            <button
              onClick={() => setCurrentTab('workshop')}
              className={`px-4 py-2 rounded text-xs font-bold ${
                isModern ? 'bg-amber-400 hover:bg-amber-300 text-slate-950' : 'bg-[#ffc83b] text-black'
              }`}
            >
              Перейти в график цеха (Гант)
            </button>
          </div>
        )}

        {/* Admin view */}
        {currentTab === 'admin' && (
          <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full space-y-4">
            <div>
              <h2 className="text-xl font-bold text-white mb-1">Панель администратора</h2>
              <p className="text-xs text-slate-400">Управление ролями, производственными циклами и базой данных</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div 
                onClick={() => setIsWorkModalOpen(true)}
                className={`p-4 rounded-lg cursor-pointer transition-all border ${
                  isModern ? 'bg-[#131622] hover:bg-[#181c2b] border-white/[0.08]' : 'bg-black border-[#4d4022]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Sliders className="w-5 h-5 text-amber-400" />
                  <div>
                    <div className="text-sm font-bold text-white">Виды работ (для графика)</div>
                    <div className="text-xs text-slate-400">Настройка этапов: Резка, Сварка, Покраска, Гибка</div>
                  </div>
                </div>
              </div>

              <div 
                onClick={() => setIsPaletteModalOpen(true)}
                className={`p-4 rounded-lg cursor-pointer transition-all border ${
                  isModern ? 'bg-[#131622] hover:bg-[#181c2b] border-white/[0.08]' : 'bg-black border-[#4d4022]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Database className="w-5 h-5 text-sky-400" />
                  <div>
                    <div className="text-sm font-bold text-white">Цветовые токены палитры</div>
                    <div className="text-xs text-slate-400">Просмотр и копирование HEX-кодов темы</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Interactive Modals */}
      <WorkTypesModal
        isOpen={isWorkModalOpen}
        onClose={() => setIsWorkModalOpen(false)}
        themeStyle={themeStyle}
        accent={accent}
      />

      <DevPromptModal
        isOpen={isPromptModalOpen}
        onClose={() => setIsPromptModalOpen(false)}
      />

      <PaletteTokensModal
        isOpen={isPaletteModalOpen}
        onClose={() => setIsPaletteModalOpen(false)}
        accent={accent}
      />
    </div>
  );
}

export default App;
