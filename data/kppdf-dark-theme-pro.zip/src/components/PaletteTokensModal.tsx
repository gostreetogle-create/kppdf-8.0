import React, { useState } from 'react';
import { X, Copy, Check, Palette } from 'lucide-react';
import { AccentColor } from '../types';

interface PaletteTokensModalProps {
  isOpen: boolean;
  onClose: () => void;
  accent: AccentColor;
}

export const PaletteTokensModal: React.FC<PaletteTokensModalProps> = ({
  isOpen,
  onClose,
  accent
}) => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1800);
  };

  const tokenGroups = [
    {
      name: 'Уровни поверхностей (Elevation Hierarchy)',
      description: 'Вместо одного глухого #000000 используются 4 матовых графитовых слоя с оптической глубиной',
      tokens: [
        { name: 'Canvas (Базовый фон)', hex: '#0C0E14', note: 'Основной фон приложения, мягче чистого черного на 12%' },
        { name: 'Surface 1 (Панели и шапка)', hex: '#141722', note: 'Шапка, боковые панели, карточки 1-го уровня' },
        { name: 'Surface 2 (Строки и инпуты)', hex: '#1B1F2E', note: 'Строки таблиц, фон инпутов, модальные окна' },
        { name: 'Surface 3 (Hover и фокус)', hex: '#242A3E', note: 'Активные строчки, наведение мыши, тултипы' },
      ]
    },
    {
      name: 'Границы и разделители (Subtle Borders)',
      description: 'Вместо желтых проволочных рамок 1px применяются деликатные прозрачные границы',
      tokens: [
        { name: 'Border Subtle', hex: 'rgba(255, 255, 255, 0.07)', note: 'Сетка таблиц, разделители блоков' },
        { name: 'Border Medium', hex: 'rgba(255, 255, 255, 0.12)', note: 'Контуры модальных окон и карточек' },
        { name: 'Border Accent Active', hex: 'rgba(245, 158, 11, 0.4)', note: 'Подсветка фокуса в полях ввода' },
      ]
    },
    {
      name: 'Технологические операции (Диаграмма Ганта)',
      description: 'Высококонтрастные цвета для видов работ в цехе с читаемым белым текстом (WCAG AA)',
      tokens: [
        { name: 'Резка металла', hex: '#0284C7', note: 'Стальной циан / лазерная резка' },
        { name: 'Сварка', hex: '#6366F1', note: 'Ультрамариновый индиго' },
        { name: 'Покраска', hex: '#10B981', note: 'Мятный изумруд / полимерно-порошковая' },
        { name: 'Гибочные работы', hex: '#F59E0B', note: 'Теплый промышленный янтарь' },
      ]
    },
    {
      name: 'Типографика и текст',
      description: 'Четкая иерархия без ослепления',
      tokens: [
        { name: 'Text Primary', hex: '#F1F5F9', note: 'Главные заголовки, статусы, цены' },
        { name: 'Text Secondary', hex: '#94A3B8', note: 'Подписи колонок, второстепенные данные' },
        { name: 'Text Muted', hex: '#64748B', note: 'Плейсхолдеры, единицы измерения' },
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn select-none">
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-xl overflow-hidden shadow-2xl bg-[#141722] border border-white/10 text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.08] bg-[#1a1f2e]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Дизайн-токены и цветовая палитра Pro Dark
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Кликните по любому цвету для копирования точного HEX-значения
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {tokenGroups.map((group, gIdx) => (
            <div key={gIdx} className="space-y-2.5">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400/90 font-mono">
                  {group.name}
                </h4>
                <p className="text-xs text-slate-400">{group.description}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {group.tokens.map((tok, tIdx) => (
                  <div
                    key={tIdx}
                    onClick={() => copyHex(tok.hex)}
                    className="p-3 rounded-lg bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.07] cursor-pointer transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-7 h-7 rounded-md border border-white/20 shadow-sm flex-shrink-0"
                        style={{ backgroundColor: tok.hex }}
                      />
                      <div>
                        <div className="text-xs font-semibold text-white group-hover:text-amber-300 transition-colors">
                          {tok.name}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {tok.note}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 pl-2">
                      <span className="font-mono text-xs text-slate-300 group-hover:text-white">
                        {tok.hex}
                      </span>
                      {copiedHex === tok.hex ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 border-t border-white/[0.08] bg-[#1a1f2e]">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
