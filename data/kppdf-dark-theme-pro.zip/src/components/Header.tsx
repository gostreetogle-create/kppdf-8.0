import React from 'react';
import { 
  Users, 
  Briefcase, 
  ShoppingCart, 
  Factory, 
  Warehouse, 
  FileText, 
  BookOpen, 
  ShieldCheck, 
  Bell, 
  Monitor, 
  LogOut, 
  Sparkles, 
  History, 
  Code2, 
  Palette,
  Sliders
} from 'lucide-react';
import { MainTab, ThemeStyle, AccentColor } from '../types';

interface HeaderProps {
  currentTab: MainTab;
  onSelectTab: (tab: MainTab) => void;
  themeStyle: ThemeStyle;
  onToggleThemeStyle: (style: ThemeStyle) => void;
  accent: AccentColor;
  onChangeAccent: (accent: AccentColor) => void;
  onOpenWorkModal: () => void;
  onOpenPromptModal: () => void;
  onOpenPaletteModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  themeStyle,
  onToggleThemeStyle,
  accent,
  onChangeAccent,
  onOpenWorkModal,
  onOpenPromptModal,
  onOpenPaletteModal
}) => {
  const isModern = themeStyle === 'modern';

  const tabs: { id: MainTab; label: string; icon: React.ReactNode }[] = [
    { id: 'clients', label: 'Клиенты', icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'deals', label: 'Сделки', icon: <Briefcase className="w-3.5 h-3.5" /> },
    { id: 'procurement', label: 'Снабж.', icon: <ShoppingCart className="w-3.5 h-3.5" /> },
    { id: 'workshop', label: 'Цех', icon: <Factory className="w-3.5 h-3.5" /> },
    { id: 'warehouse', label: 'Склад', icon: <Warehouse className="w-3.5 h-3.5" /> },
    { id: 'documents', label: 'Докум.', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'registers', label: 'Реестры', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'admin', label: 'Админ', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
  ];

  // Dynamic accent style classes
  const getAccentBg = () => {
    switch (accent) {
      case 'blue': return 'bg-sky-500 text-slate-950';
      case 'emerald': return 'bg-emerald-500 text-slate-950';
      case 'cyan': return 'bg-cyan-400 text-slate-950';
      case 'amber':
      default: return 'bg-amber-400 text-slate-950';
    }
  };

  const getAccentBadge = () => {
    switch (accent) {
      case 'blue': return 'bg-sky-500/15 text-sky-400 border-sky-500/30';
      case 'emerald': return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'cyan': return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
      case 'amber':
      default: return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
    }
  };

  return (
    <header 
      id="app-header" 
      className={`w-full transition-colors duration-200 select-none z-30 sticky top-0 ${
        isModern 
          ? 'bg-[#12151f]/95 backdrop-blur-md border-b border-white/[0.08] shadow-lg shadow-black/20' 
          : 'bg-black border-b border-[#3d3319]'
      }`}
    >
      <div className="flex items-center justify-between px-3 py-1.5 h-14">
        {/* Left: Brand & Main Navigation */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 pr-2 border-r border-white/10">
            <span className={`w-3 h-3 rounded-sm ${isModern ? (accent === 'blue' ? 'bg-sky-400 shadow-sm shadow-sky-400/50' : accent === 'emerald' ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50' : accent === 'cyan' ? 'bg-cyan-400' : 'bg-amber-400 shadow-sm shadow-amber-400/50') : 'bg-amber-400'}`} />
            <div className="flex items-baseline gap-1.5">
              <span className="font-bold tracking-wider text-sm text-white">KPPDF</span>
              <span className="text-xs font-mono text-slate-400">8.0</span>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="flex items-center gap-0.5">
            {tabs.map((tab) => {
              const isActive = currentTab === tab.id;
              
              if (!isModern) {
                // Legacy style: harsh solid yellow square with black text or black with sharp border
                return (
                  <button
                    key={tab.id}
                    id={`nav-tab-${tab.id}`}
                    onClick={() => onSelectTab(tab.id)}
                    className={`flex flex-col items-center justify-center px-3 py-1 min-w-[62px] text-[11px] font-medium transition-none ${
                      isActive 
                        ? 'bg-[#ffc83b] text-black font-semibold' 
                        : 'bg-[#0d0d0d] text-slate-300 border border-[#3d3319] hover:bg-[#1a1a1a]'
                    }`}
                  >
                    <div className="mb-0.5">{tab.icon}</div>
                    <span>{tab.label}</span>
                  </button>
                );
              }

              // Modern Pro Dark style: elegant tab with subtle indicator & soft glow
              return (
                <button
                  key={tab.id}
                  id={`nav-tab-${tab.id}`}
                  onClick={() => onSelectTab(tab.id)}
                  className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-150 ${
                    isActive 
                      ? `${getAccentBadge()} shadow-sm` 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                  {isActive && (
                    <span 
                      className={`absolute -bottom-[9px] left-3 right-3 h-[2px] rounded-full ${
                        accent === 'blue' ? 'bg-sky-400' : accent === 'emerald' ? 'bg-emerald-400' : accent === 'cyan' ? 'bg-cyan-400' : 'bg-amber-400'
                      }`} 
                    />
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Center / Right: Mode Switcher & Tools */}
        <div className="flex items-center gap-2.5">
          {/* Quick Trigger: Work Modal */}
          <button
            id="open-work-modal-btn"
            onClick={onOpenWorkModal}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium transition-all ${
              isModern
                ? 'bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-white/10 hover:border-white/20'
                : 'bg-black text-amber-300 border border-[#4d4022] hover:bg-[#111]'
            }`}
            title="Открыть модальное окно «Виды работ» из скриншота 1"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden xl:inline">Виды работ (Модалка)</span>
            <span className="xl:hidden">Виды работ</span>
          </button>

          {/* Tokens & Prompt buttons */}
          <button
            id="open-tokens-btn"
            onClick={onOpenPaletteModal}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium transition-all ${
              isModern
                ? 'bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-white/10'
                : 'bg-black text-slate-300 border border-[#4d4022]'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Палитра цветов</span>
          </button>

          <button
            id="open-prompt-btn"
            onClick={onOpenPromptModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold shadow-sm transition-all ${
              isModern
                ? (accent === 'blue' ? 'bg-sky-500 hover:bg-sky-400 text-slate-950' : accent === 'emerald' ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950' : accent === 'cyan' ? 'bg-cyan-400 hover:bg-cyan-300 text-slate-950' : 'bg-amber-400 hover:bg-amber-300 text-slate-950')
                : 'bg-[#ffc83b] text-black hover:bg-[#e0b033]'
            }`}
            title="Получить готовый промпт для нейросети / разработчика"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Промпт для ИИ</span>
          </button>

          {/* Modern / Legacy Comparison Toggle */}
          <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-white/10 ml-1">
            <button
              id="theme-toggle-legacy"
              onClick={() => onToggleThemeStyle('legacy')}
              className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-all ${
                !isModern 
                  ? 'bg-amber-500 text-black font-semibold shadow' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Показать текущую исходную темную тему со скриншотов"
            >
              <History className="w-3 h-3" />
              <span>Было (Скрины)</span>
            </button>
            <button
              id="theme-toggle-modern"
              onClick={() => onToggleThemeStyle('modern')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
                isModern 
                  ? `${getAccentBg()} font-semibold shadow-sm` 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Показать обновленную профессиональную тему Pro Dark"
            >
              <Sparkles className="w-3 h-3" />
              <span>Стало (Pro Dark)</span>
            </button>
          </div>

          {/* Accent Color Switcher (Only visible in Modern) */}
          {isModern && (
            <div className="hidden sm:flex items-center gap-1 pl-2 border-l border-white/10">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-mono mr-1">Акцент:</span>
              <button
                onClick={() => onChangeAccent('amber')}
                className={`w-4 h-4 rounded-full bg-amber-400 transition-transform ${accent === 'amber' ? 'ring-2 ring-amber-400 ring-offset-2 ring-offset-slate-900 scale-110' : 'opacity-60 hover:opacity-100'}`}
                title="Industrial Amber"
              />
              <button
                onClick={() => onChangeAccent('blue')}
                className={`w-4 h-4 rounded-full bg-sky-400 transition-transform ${accent === 'blue' ? 'ring-2 ring-sky-400 ring-offset-2 ring-offset-slate-900 scale-110' : 'opacity-60 hover:opacity-100'}`}
                title="Titanium Sky"
              />
              <button
                onClick={() => onChangeAccent('emerald')}
                className={`w-4 h-4 rounded-full bg-emerald-400 transition-transform ${accent === 'emerald' ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-900 scale-110' : 'opacity-60 hover:opacity-100'}`}
                title="Precision Emerald"
              />
              <button
                onClick={() => onChangeAccent('cyan')}
                className={`w-4 h-4 rounded-full bg-cyan-400 transition-transform ${accent === 'cyan' ? 'ring-2 ring-cyan-400 ring-offset-2 ring-offset-slate-900 scale-110' : 'opacity-60 hover:opacity-100'}`}
                title="Cyber Cyan"
              />
            </div>
          )}

          {/* Profile & Utilities */}
          <div className="flex items-center gap-1.5 pl-2 border-l border-white/10 text-slate-400">
            <button className="p-1.5 hover:text-white hover:bg-white/5 rounded">
              <Bell className="w-3.5 h-3.5" />
            </button>
            <button className="p-1.5 hover:text-white hover:bg-white/5 rounded">
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <div className="flex items-center gap-1 px-1.5 py-0.5 text-xs text-slate-300 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span className="hidden md:inline text-[11px] truncate max-w-[110px]">Default Administr...</span>
            </div>
            <button className="p-1.5 hover:text-red-400 hover:bg-white/5 rounded">
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
