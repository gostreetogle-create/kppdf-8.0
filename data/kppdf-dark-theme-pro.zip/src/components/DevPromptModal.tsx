import React, { useState } from 'react';
import { X, Copy, Check, Sparkles, Terminal, FileCode, HelpCircle } from 'lucide-react';
import { MASTER_PROMPT_RU, TAILWIND_CONFIG_SNIPPET, THEME_ANALYSIS } from '../data/promptData';

interface DevPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DevPromptModal: React.FC<DevPromptModalProps> = ({ isOpen, onClose }) => {
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [copiedCss, setCopiedCss] = useState(false);
  const [activeTab, setActiveTab] = useState<'prompt' | 'css' | 'analysis'>('prompt');

  if (!isOpen) return null;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(MASTER_PROMPT_RU);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2500);
  };

  const handleCopyCss = () => {
    navigator.clipboard.writeText(TAILWIND_CONFIG_SNIPPET);
    setCopiedCss(true);
    setTimeout(() => setCopiedCss(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn select-none">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-xl overflow-hidden shadow-2xl bg-[#141722] border border-white/10 text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.08] bg-[#1a1f2e]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Промпт для починки тёмной темы в вашем приложении
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Скопируйте этот текст в Cursor, Claude 3.5 Sonnet, ChatGPT или передайте вашему разработчику
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selector */}
        <div className="flex border-b border-white/[0.08] px-6 bg-[#161a27]">
          <button
            onClick={() => setActiveTab('prompt')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'prompt'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Готовый промпт для ИИ</span>
          </button>
          <button
            onClick={() => setActiveTab('css')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'css'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>CSS Variables / Tailwind</span>
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'analysis'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Анализ ошибок со скриншотов</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'prompt' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Этот промпт составлен с учётом всех нюансов ваших 12 скриншотов (сетка, диаграмма Ганта, шапка, таблицы, модалки):
                </span>
                <button
                  onClick={handleCopyPrompt}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-md ${
                    copiedPrompt 
                      ? 'bg-emerald-500 text-slate-950' 
                      : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                  }`}
                >
                  {copiedPrompt ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedPrompt ? 'Скопировано в буфер!' : 'Скопировать весь промпт'}</span>
                </button>
              </div>

              <div className="relative">
                <pre className="p-4 rounded-lg bg-[#0c0e14] border border-white/10 text-[12px] font-mono leading-relaxed text-slate-300 whitespace-pre-wrap max-h-[460px] overflow-y-auto select-text">
                  {MASTER_PROMPT_RU}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'css' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Вставьте эти переменные в ваш глобальный файл стилей (`globals.css`, `index.css` или `tailwind.config.js`):
                </span>
                <button
                  onClick={handleCopyCss}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-md ${
                    copiedCss 
                      ? 'bg-emerald-500 text-slate-950' 
                      : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
                  }`}
                >
                  {copiedCss ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedCss ? 'Скопировано в буфер!' : 'Скопировать CSS токены'}</span>
                </button>
              </div>

              <pre className="p-4 rounded-lg bg-[#0c0e14] border border-white/10 text-[12px] font-mono leading-relaxed text-amber-300/90 whitespace-pre-wrap select-text">
                {TAILWIND_CONFIG_SNIPPET}
              </pre>
            </div>
          )}

          {activeTab === 'analysis' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-400 mb-2">
                Мы детально проанализировали каждый из 12 присланных вами скриншотов системы KPPDF 8.0:
              </div>
              <div className="grid grid-cols-1 gap-3">
                {THEME_ANALYSIS.map((item, idx) => (
                  <div key={idx} className="p-4 rounded-lg bg-white/[0.03] border border-white/[0.08] space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-red-500/20 text-red-400 text-xs font-mono font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <h4 className="text-sm font-bold text-white">{item.title}</h4>
                    </div>
                    <div className="text-xs text-red-300/80 bg-red-950/20 p-2.5 rounded border border-red-900/30">
                      <strong>Проблема на скринах:</strong> {item.problem}
                    </div>
                    <div className="text-xs text-emerald-300/90 bg-emerald-950/20 p-2.5 rounded border border-emerald-900/30">
                      <strong>Как исправлено в Pro Dark:</strong> {item.solution}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-white/[0.08] bg-[#1a1f2e]">
          <span className="text-xs text-slate-400">
            KPPDF 8.0 Dark Theme Architecture Guide
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
