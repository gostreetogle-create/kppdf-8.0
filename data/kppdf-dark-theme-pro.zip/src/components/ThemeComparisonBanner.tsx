import React, { useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Eye, 
  Layers, 
  Maximize2, 
  Minimize2,
  Sparkles,
  Zap
} from 'lucide-react';
import { ThemeStyle, AccentColor } from '../types';

interface ThemeComparisonBannerProps {
  themeStyle: ThemeStyle;
  onToggleThemeStyle: (style: ThemeStyle) => void;
  accent: AccentColor;
  onOpenPrompt: () => void;
}

export const ThemeComparisonBanner: React.FC<ThemeComparisonBannerProps> = ({
  themeStyle,
  onToggleThemeStyle,
  accent,
  onOpenPrompt
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isModern = themeStyle === 'modern';

  return (
    <div 
      id="theme-comparison-banner"
      className={`w-full text-xs transition-colors duration-200 border-b ${
        isModern
          ? 'bg-gradient-to-r from-[#141724] via-[#171c2c] to-[#141724] border-white/10 text-slate-300'
          : 'bg-[#120f07] border-[#4d4022] text-[#e8d7a7]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Status and Quick summary */}
        <div className="flex items-center gap-2.5">
          <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded font-mono text-[11px] font-semibold ${
            isModern 
              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
          }`}>
            {isModern ? <Sparkles className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
            <span>{isModern ? 'PRO DARK THEME' : 'ОРИГИНАЛ (ИЗ СКРИНШОТОВ)'}</span>
          </div>

          <div className="text-xs">
            {isModern ? (
              <span>
                <strong className="text-white font-medium">Мягкая глубина и многослойность:</strong> устранены проволочные рамки, фон разгружен с #000000 до благородного графита #0C0E14, Гант легко читается.
              </span>
            ) : (
              <span>
                <strong className="text-amber-200 font-medium">Исходное состояние:</strong> глухой 100% черный фон, резкие желтые рамки на всех блоках, бежевые плашки на Ганте без читаемого контраста.
              </span>
            )}
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onToggleThemeStyle(isModern ? 'legacy' : 'modern')}
            className={`px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1.5 transition-all shadow-sm ${
              isModern
                ? 'bg-white/10 hover:bg-white/15 text-white border border-white/10'
                : 'bg-amber-400 text-black hover:bg-amber-300 font-bold'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Переключить: {isModern ? '«Было»' : '«Стало»'}</span>
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-white/5"
          >
            <span>{isExpanded ? 'Скрыть аудит' : 'Аудит 5 ошибок'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expanded Detailed Audit Drawer */}
      {isExpanded && (
        <div className="border-t border-white/10 bg-black/40 px-4 py-3 backdrop-blur-md">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06]">
              <div className="text-[11px] font-bold text-red-400 flex items-center gap-1 mb-1">
                <span>1. Глухой #000000 фон</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                На чистом черном глаза устают. Исправлено на 4-уровневую систему поверхностей (Canvas #0C0E14 &rarr; Panel #141722 &rarr; Card #1B1F2E).
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06]">
              <div className="text-[11px] font-bold text-red-400 flex items-center gap-1 mb-1">
                <span>2. Проволочные рамки</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Желтые рамки 1px на каждом инпуте и карточке заменены на деликатную границу rgba(255,255,255,0.07).
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06]">
              <div className="text-[11px] font-bold text-red-400 flex items-center gap-1 mb-1">
                <span>3. Гант: цвета и сетка</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Убраны бежевые полосы с нечитаемым белым текстом. Введены контрастные капсулы (Циан, Индиго, Мята, Янтарь) и затемненные выходные.
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06]">
              <div className="text-[11px] font-bold text-red-400 flex items-center gap-1 mb-1">
                <span>4. Едкий желтый акцент</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                Ядовито-желтый заменен на благородный янтарный Warm Industrial Amber (#F59E0B) с мягким фоновым свечением.
              </p>
            </div>

            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06] flex flex-col justify-between">
              <div>
                <div className="text-[11px] font-bold text-emerald-400 flex items-center gap-1 mb-1">
                  <span>5. Готовое решение</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  Скопируйте системный промпт или переменные CSS для вашего разработчика в 1 клик.
                </p>
              </div>
              <button
                onClick={onOpenPrompt}
                className="mt-2 text-[11px] font-semibold text-amber-400 hover:text-amber-300 underline text-left"
              >
                Открыть промпт &rarr;
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
