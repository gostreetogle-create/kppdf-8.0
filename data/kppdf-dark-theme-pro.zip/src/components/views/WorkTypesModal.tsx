import React, { useState } from 'react';
import { 
  X, 
  ArrowUp, 
  ArrowDown, 
  Edit2, 
  Trash2, 
  Plus, 
  Info,
  Check
} from 'lucide-react';
import { ThemeStyle, AccentColor, WorkTypeItem } from '../../types';
import { MOCK_WORK_TYPES } from '../../data/mockData';

interface WorkTypesModalProps {
  isOpen: boolean;
  onClose: () => void;
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const WorkTypesModal: React.FC<WorkTypesModalProps> = ({
  isOpen,
  onClose,
  themeStyle,
  accent
}) => {
  const isModern = themeStyle === 'modern';
  const [workTypes, setWorkTypes] = useState<WorkTypeItem[]>(MOCK_WORK_TYPES);

  if (!isOpen) return null;

  const moveItem = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= workTypes.length) return;
    const newItems = [...workTypes];
    const temp = newItems[index];
    newItems[index] = newItems[targetIndex];
    newItems[targetIndex] = temp;
    // update order numbers
    newItems.forEach((it, idx) => it.order = idx + 1);
    setWorkTypes(newItems);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div 
        className={`w-full max-w-3xl rounded-xl overflow-hidden shadow-2xl transition-colors ${
          isModern 
            ? 'bg-[#151926] border border-white/10 text-slate-200' 
            : 'bg-black border border-[#4d4022] text-[#e8d7a7]'
        }`}
      >
        {/* Modal Header */}
        <div className={`flex items-center justify-between px-6 py-4 border-b ${
          isModern ? 'border-white/[0.08] bg-[#1a1f2e]' : 'border-[#4d4022] bg-black'
        }`}>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">Виды работ (для графика)</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Вид определяет название этапа, цвет на графике и порядок по умолчанию в технологической цепочке.
            </p>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-4">
          <div className="overflow-x-auto border border-white/[0.06] rounded-lg">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className={`border-b ${
                  isModern 
                    ? 'bg-[#1a1f2e] text-slate-400 border-white/[0.06]' 
                    : 'bg-black text-white border-[#4d4022]'
                }`}>
                  <th className="py-2.5 px-3 font-medium text-center w-12">Порядок</th>
                  <th className="py-2.5 px-4 font-medium">Название</th>
                  <th className="py-2.5 px-3 font-medium">Код</th>
                  <th className="py-2.5 px-4 font-medium">Цвет на графике</th>
                  <th className="py-2.5 px-3 font-medium text-right">Норма по умолч.</th>
                  <th className="py-2.5 px-4 font-medium text-right">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {workTypes.map((item, index) => (
                  <tr 
                    key={item.id}
                    className={`transition-colors ${
                      isModern ? 'hover:bg-white/[0.02]' : 'hover:bg-[#141414]'
                    }`}
                  >
                    <td className="py-3 px-3 text-center font-mono text-slate-400">
                      {item.order}
                    </td>
                    <td className="py-3 px-4 font-medium text-white">
                      {item.name}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">
                      {item.code}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-5 h-5 rounded border border-white/20 shadow-sm"
                          style={{ backgroundColor: isModern ? item.colorModern : item.color }}
                        />
                        <span className="font-mono text-[11px] text-slate-300">
                          {isModern ? item.colorModern : item.color}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-300">
                      {item.defaultNorm}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button 
                          disabled={index === 0}
                          onClick={() => moveItem(index, 'up')}
                          className={`p-1 rounded transition-colors ${
                            index === 0 
                              ? 'text-slate-600 cursor-not-allowed' 
                              : isModern 
                                ? 'hover:bg-white/10 text-slate-300' 
                                : 'border border-[#4d4022] text-[#c2b28f]'
                          }`}
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          disabled={index === workTypes.length - 1}
                          onClick={() => moveItem(index, 'down')}
                          className={`p-1 rounded transition-colors ${
                            index === workTypes.length - 1 
                              ? 'text-slate-600 cursor-not-allowed' 
                              : isModern 
                                ? 'hover:bg-white/10 text-slate-300' 
                                : 'border border-[#4d4022] text-[#c2b28f]'
                          }`}
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                        <button className={`p-1 rounded ml-1 ${isModern ? 'hover:bg-white/10 text-slate-300' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button className={`p-1 rounded ${isModern ? 'hover:bg-red-500/20 text-slate-400 hover:text-red-400' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <button
            className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-bold transition-all ${
              isModern
                ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold'
                : 'bg-[#ffc83b] text-black hover:bg-[#e6b435]'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>ДОБАВИТЬ ВИД РАБОТ</span>
          </button>
        </div>

        {/* Modal Footer */}
        <div className={`flex items-center justify-end px-6 py-3 border-t ${
          isModern ? 'border-white/[0.08] bg-[#1a1f2e]' : 'border-[#4d4022] bg-black'
        }`}>
          <button
            onClick={onClose}
            className={`px-4 py-1.5 rounded text-xs font-medium transition-colors ${
              isModern
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10'
                : 'bg-black text-white border border-[#4d4022]'
            }`}
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
