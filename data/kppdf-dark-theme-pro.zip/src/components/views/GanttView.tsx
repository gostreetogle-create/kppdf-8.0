import React, { useState } from 'react';
import { 
  Calendar, 
  ChevronDown, 
  ChevronRight, 
  Clock, 
  Filter, 
  Maximize, 
  RefreshCw, 
  RotateCcw, 
  SlidersHorizontal, 
  UserCheck, 
  AlertCircle,
  ArrowLeft,
  CalendarDays,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { ThemeStyle, AccentColor, GanttItem } from '../../types';
import { MOCK_GANTT_ORDERS } from '../../data/mockData';

interface GanttViewProps {
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const GanttView: React.FC<GanttViewProps> = ({ themeStyle, accent }) => {
  const isModern = themeStyle === 'modern';
  const [activeSubTab, setActiveSubTab] = useState<'orders' | 'workers'>('orders');
  const [scale, setScale] = useState<'day' | 'month' | 'fit'>('day');
  const [orders, setOrders] = useState<GanttItem[]>(MOCK_GANTT_ORDERS);
  const [selectedTask, setSelectedTask] = useState<string | null>('t-4');

  const daysList = [
    { date: '17.07', day: 'ПТ', isWeekend: false, dayNum: 0 },
    { date: '18.07', day: 'СБ', isWeekend: true, dayNum: 1 },
    { date: '19.07', day: 'ВС', isWeekend: true, dayNum: 2 },
    { date: '20.07', day: 'ПН', isWeekend: false, dayNum: 3 },
    { date: '21.07', day: 'ВТ', isWeekend: false, dayNum: 4 },
    { date: '22.07', day: 'СР', isWeekend: false, dayNum: 5 },
    { date: '23.07', day: 'ЧТ', isWeekend: false, dayNum: 6 },
    { date: '24.07', day: 'ПТ', isWeekend: false, dayNum: 7 },
    { date: '25.07', day: 'СБ', isWeekend: true, dayNum: 8 },
    { date: '26.07', day: 'ВС', isWeekend: true, dayNum: 9 },
    { date: '27.07', day: 'ПН', isWeekend: false, dayNum: 10 },
    { date: '28.07', day: 'ВТ', isWeekend: false, dayNum: 11 },
    { date: '29.07', day: 'СР', isWeekend: false, dayNum: 12 },
    { date: '30.07', day: 'ЧТ', isWeekend: false, dayNum: 13 },
    { date: '31.07', day: 'ПТ', isWeekend: false, dayNum: 14 },
    { date: '01.08', day: 'СБ', isWeekend: true, dayNum: 15 },
    { date: '02.08', day: 'ВС', isWeekend: true, dayNum: 16 },
    { date: '03.08', day: 'ПН', isWeekend: false, dayNum: 17 },
    { date: '04.08', day: 'ВТ', isWeekend: false, dayNum: 18 },
    { date: '05.08', day: 'СР', isWeekend: false, dayNum: 19 },
    { date: '06.08', day: 'ЧТ', isWeekend: false, dayNum: 20 },
    { date: '07.08', day: 'ПТ', isWeekend: false, dayNum: 21 },
    { date: '08.08', day: 'СБ', isWeekend: true, dayNum: 22 },
    { date: '09.08', day: 'ВС', isWeekend: true, dayNum: 23 },
    { date: '10.08', day: 'ПН', isWeekend: false, dayNum: 24 },
    { date: '11.08', day: 'ВТ', isWeekend: false, dayNum: 25 },
    { date: '12.08', day: 'СР', isWeekend: false, dayNum: 26 },
    { date: '13.08', day: 'ЧТ', isWeekend: false, dayNum: 27 },
    { date: '14.08', day: 'ПТ', isWeekend: false, dayNum: 28 },
    { date: '15.08', day: 'СБ', isWeekend: true, dayNum: 29 },
    { date: '16.08', day: 'ВС', isWeekend: true, dayNum: 30 },
    { date: '17.08', day: 'ПН', isWeekend: false, dayNum: 31 },
    { date: '18.08', day: 'ВТ', isWeekend: false, dayNum: 32 },
    { date: '19.08', day: 'СР', isWeekend: false, dayNum: 33 },
    { date: '20.08', day: 'ЧТ', isWeekend: false, dayNum: 34 },
    { date: '21.08', day: 'ПТ', isWeekend: false, dayNum: 35 },
    { date: '22.08', day: 'СБ', isWeekend: true, dayNum: 36 },
  ];

  const toggleExpand = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, isExpanded: !o.isExpanded } : o));
  };

  // Operation colors based on theme
  const getOperationBadgeStyle = (type: string) => {
    if (!isModern) {
      // Legacy colors from screenshot: dull greens, strange purples
      switch (type) {
        case 'cutting': return 'bg-[#89a852] text-white';
        case 'welding': return 'bg-[#8a82d0] text-white';
        case 'painting': return 'bg-[#7ba94a] text-white';
        case 'bending': return 'bg-[#91ad4b] text-white';
        default: return 'bg-[#d6cbbe] text-[#333]';
      }
    }

    // Modern colors: balanced, high-contrast, luminous
    switch (type) {
      case 'cutting': 
        return 'bg-gradient-to-r from-sky-600 to-sky-500 text-white border border-sky-400/40 shadow-sm shadow-sky-950/50';
      case 'welding': 
        return 'bg-gradient-to-r from-indigo-600 to-indigo-500 text-white border border-indigo-400/40 shadow-sm shadow-indigo-950/50';
      case 'painting': 
        return 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white border border-emerald-400/40 shadow-sm shadow-emerald-950/50';
      case 'bending': 
        return 'bg-gradient-to-r from-amber-600 to-amber-500 text-white border border-amber-400/40 shadow-sm shadow-amber-950/50';
      default: 
        return 'bg-slate-700 text-slate-200 border border-slate-600';
    }
  };

  return (
    <div 
      id="gantt-view-container"
      className={`w-full flex-1 flex flex-col overflow-hidden select-none ${
        isModern ? 'bg-[#0c0e14] text-slate-200' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      {/* Sub-Header Toolbar */}
      <div className={`flex flex-wrap items-center justify-between px-3 py-2 border-b ${
        isModern 
          ? 'bg-[#141722] border-white/[0.08]' 
          : 'bg-black border-[#4d4022]'
      }`}>
        <div className="flex items-center gap-3">
          {/* Back button */}
          <button className={`p-1.5 rounded transition-colors ${
            isModern 
              ? 'hover:bg-white/10 text-slate-400 hover:text-white' 
              : 'border border-[#4d4022] hover:bg-[#1a1a1a] text-amber-400'
          }`}>
            <ArrowLeft className="w-4 h-4" />
          </button>

          {/* Subtabs: "По заказам" / "По рабочим" */}
          <div className="flex items-center">
            <button
              onClick={() => setActiveSubTab('orders')}
              className={`px-3 py-1 text-xs font-semibold rounded-l transition-all ${
                activeSubTab === 'orders'
                  ? isModern 
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' 
                    : 'bg-white text-black font-bold'
                  : isModern 
                    ? 'bg-slate-800/90 text-slate-300 hover:bg-slate-700' 
                    : 'bg-[#111] text-[#999] border border-[#4d4022]'
              }`}
            >
              По заказам
            </button>
            <button
              onClick={() => setActiveSubTab('workers')}
              className={`px-3 py-1 text-xs font-semibold rounded-r transition-all ${
                activeSubTab === 'workers'
                  ? isModern 
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' 
                    : 'bg-white text-black font-bold'
                  : isModern 
                    ? 'bg-slate-800/90 text-slate-300 hover:bg-slate-700' 
                    : 'bg-[#111] text-[#999] border border-l-0 border-[#4d4022]'
              }`}
            >
              По рабочим
            </button>
          </div>

          {/* Warning Banner: Missing assignments */}
          <div className={`hidden md:flex items-center gap-2 px-2.5 py-1 text-[11px] rounded ${
            isModern
              ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
              : 'text-amber-400 border border-[#4d4022]'
          }`}>
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
            <span>Без исполнителя: <strong>4 видов работ</strong> — назначьте в <span className="underline cursor-pointer">Люди</span></span>
          </div>
        </div>

        {/* Right side: Legend & Scale Switchers */}
        <div className="flex items-center gap-4">
          {/* Work type color legend */}
          <div className="hidden xl:flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-sm ${isModern ? 'bg-sky-500' : 'bg-[#89a852]'}`} />
              <span className={isModern ? 'text-slate-300' : 'text-[#c2b28f]'}>Резка металла</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-sm ${isModern ? 'bg-indigo-500' : 'bg-[#8a82d0]'}`} />
              <span className={isModern ? 'text-slate-300' : 'text-[#c2b28f]'}>Сварка</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-sm ${isModern ? 'bg-emerald-500' : 'bg-[#7ba94a]'}`} />
              <span className={isModern ? 'text-slate-300' : 'text-[#c2b28f]'}>Покраска</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-sm ${isModern ? 'bg-amber-500' : 'bg-[#91ad4b]'}`} />
              <span className={isModern ? 'text-slate-300' : 'text-[#c2b28f]'}>Гибочные работы</span>
            </span>
          </div>

          {/* Scale Buttons */}
          <div className="flex items-center">
            {(['day', 'month', 'fit'] as const).map((s, idx) => (
              <button
                key={s}
                onClick={() => setScale(s)}
                className={`px-2.5 py-1 text-[11px] font-medium transition-all ${
                  idx === 0 ? 'rounded-l' : idx === 2 ? 'rounded-r' : ''
                } ${
                  scale === s
                    ? isModern 
                      ? 'bg-slate-700 text-white font-semibold' 
                      : 'bg-white text-black font-semibold'
                    : isModern 
                      ? 'bg-slate-800/80 text-slate-400 hover:text-slate-200' 
                      : 'bg-[#111] text-slate-400 border border-[#4d4022]'
                }`}
              >
                {s === 'day' ? 'День' : s === 'month' ? 'Месяц' : 'Вместить сроки'}
              </button>
            ))}
          </div>

          {/* Side action buttons */}
          <div className="flex items-center gap-1">
            <button className={`p-1.5 rounded ${isModern ? 'hover:bg-white/10 text-slate-400' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
              <CalendarDays className="w-3.5 h-3.5" />
            </button>
            <button className={`p-1.5 rounded ${isModern ? 'hover:bg-white/10 text-slate-400' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Gantt Body: Left Sidebar + Timeline Grid */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Column: Orders / Task Names */}
        <div className={`w-64 sm:w-72 flex-shrink-0 flex flex-col border-r z-10 ${
          isModern 
            ? 'bg-[#141722] border-white/[0.08]' 
            : 'bg-black border-[#4d4022]'
        }`}>
          {/* Header */}
          <div className={`h-11 flex items-center px-4 font-semibold text-xs border-b ${
            isModern 
              ? 'bg-[#181c2a] text-slate-300 border-white/[0.08]' 
              : 'bg-black text-[#e8d7a7] border-[#4d4022]'
          }`}>
            <span>{activeSubTab === 'orders' ? 'Заказ / Элемент' : 'Рабочий'}</span>
          </div>

          {/* List of Orders and Nested Tasks */}
          <div className="flex-1 overflow-y-auto divide-y divide-white/[0.04]">
            {orders.map((order) => (
              <div key={order.id} className="text-xs">
                {/* Order Row */}
                <div 
                  onClick={() => toggleExpand(order.id)}
                  className={`flex items-center justify-between px-3 py-2.5 cursor-pointer transition-colors ${
                    isModern 
                      ? 'hover:bg-white/[0.03] text-slate-200' 
                      : 'hover:bg-[#141414] text-[#e8d7a7] border-b border-[#332b17]'
                  }`}
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    {order.sections && order.sections.length > 0 ? (
                      order.isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-amber-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                    ) : (
                      <span className="w-3.5" />
                    )}
                    <span className="font-mono font-bold text-xs tracking-tight">{order.orderNumber}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{order.totalDays}д</span>
                </div>

                {/* Expanded Sections and Operations */}
                {order.isExpanded && order.sections && (
                  <div className={isModern ? 'bg-black/20' : 'bg-[#0a0a0a]'}>
                    {order.sections.map((sec) => (
                      <div key={sec.id}>
                        {/* Section Header */}
                        <div className={`flex items-center gap-2 pl-6 pr-3 py-1.5 text-[11px] font-medium border-t border-b ${
                          isModern 
                            ? 'bg-[#1a1f2e] text-slate-300 border-white/[0.05]' 
                            : 'bg-[#111] text-amber-300 border-[#332b17]'
                        }`}>
                          <ChevronDown className="w-3 h-3 text-slate-400" />
                          <span className="truncate">{sec.title}</span>
                          <span className="ml-auto text-[10px] text-slate-500">{sec.days}д</span>
                        </div>

                        {/* Individual operations */}
                        {sec.tasks.map((task) => (
                          <div 
                            key={task.id}
                            onClick={() => setSelectedTask(task.id)}
                            className={`flex items-center gap-2 pl-9 pr-3 py-1.5 text-[11px] cursor-pointer transition-colors ${
                              selectedTask === task.id
                                ? isModern 
                                  ? 'bg-amber-500/15 text-amber-300 font-medium' 
                                  : 'bg-[#1f1d13] text-amber-300 font-bold'
                                : isModern 
                                  ? 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.02]' 
                                  : 'text-[#bbb] hover:bg-[#141414]'
                            }`}
                          >
                            <span className={`w-2 h-2 rounded-sm ${
                              task.type === 'cutting' ? (isModern ? 'bg-sky-400' : 'bg-[#89a852]') :
                              task.type === 'welding' ? (isModern ? 'bg-indigo-400' : 'bg-[#8a82d0]') :
                              task.type === 'painting' ? (isModern ? 'bg-emerald-400' : 'bg-[#7ba94a]') :
                              (isModern ? 'bg-amber-400' : 'bg-[#91ad4b]')
                            }`} />
                            <span className="truncate">{task.name}</span>
                            <span className="ml-auto text-[10px] font-mono text-slate-500">{task.durationDays}д</span>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right Area: Horizontal Timeline Columns */}
        <div className="flex-1 flex flex-col overflow-x-auto overflow-y-auto">
          {/* Day Calendar Columns Header */}
          <div className="flex min-w-max border-b h-11 sticky top-0 z-20">
            {daysList.map((d, i) => (
              <div
                key={i}
                className={`w-12 sm:w-14 flex-shrink-0 flex flex-col items-center justify-center border-r text-[10px] font-mono transition-colors ${
                  isModern
                    ? d.isWeekend 
                      ? 'bg-[#10131c] text-slate-500 border-white/[0.05]' 
                      : 'bg-[#161a26] text-slate-300 border-white/[0.07]'
                    : d.isWeekend
                      ? 'bg-[#15120a] text-amber-500/60 border-[#3d3319]'
                      : 'bg-black text-[#e8d7a7] border-[#4d4022]'
                }`}
              >
                <span className="font-semibold">{d.date}</span>
                <span className={`text-[9px] ${d.isWeekend ? 'text-amber-500/70 font-semibold' : 'text-slate-400'}`}>{d.day}</span>
              </div>
            ))}
          </div>

          {/* Timeline Grid Content */}
          <div className="relative min-w-max flex-1">
            {/* Background Grid Columns */}
            <div className="absolute inset-0 flex pointer-events-none">
              {daysList.map((d, i) => (
                <div
                  key={i}
                  className={`w-12 sm:w-14 flex-shrink-0 border-r h-full ${
                    isModern
                      ? d.isWeekend 
                        ? 'bg-black/20 border-white/[0.03]' 
                        : 'border-white/[0.04]'
                      : d.isWeekend
                        ? 'bg-[#120f06] border-[#292212]'
                        : 'border-[#332b17]'
                  }`}
                />
              ))}
            </div>

            {/* Bars for Orders and Tasks */}
            <div className="relative z-10 py-1">
              {orders.map((order) => {
                // Calculate position of order bar
                const startIdx = 
                  order.startDate === '17.07.2026' ? 0 :
                  order.startDate === '19.07.2026' ? 2 :
                  order.startDate === '23.07.2026' ? 6 :
                  order.startDate === '25.07.2026' ? 8 :
                  order.startDate === '27.07.2026' ? 10 : 4;
                
                const dayColWidth = 56; // 14px * 4 for sm screen (w-14)
                const leftPos = startIdx * dayColWidth;
                const barWidth = order.totalDays * dayColWidth;

                return (
                  <div key={order.id} className="mb-0.5">
                    {/* Main Order Bar Row */}
                    <div className="h-9 flex items-center relative">
                      <div
                        style={{ left: `${leftPos}px`, width: `${barWidth}px` }}
                        className={`absolute h-6 rounded flex items-center px-2 text-[11px] font-semibold transition-all shadow-sm ${
                          isModern
                            ? 'bg-gradient-to-r from-slate-700/90 to-slate-800/90 text-slate-100 border border-slate-500/40 backdrop-blur-sm'
                            : 'bg-[#d8cebe] text-black border border-[#a3947f]'
                        }`}
                      >
                        <span className="truncate">{order.totalDays}д</span>
                      </div>
                    </div>

                    {/* Nested tasks if expanded */}
                    {order.isExpanded && order.sections && (
                      <div className="space-y-1 my-1">
                        {order.sections.map((sec) => (
                          <div key={sec.id} className="space-y-1">
                            {/* Section sub-bar */}
                            <div className="h-7 flex items-center relative">
                              <div
                                style={{ left: `${leftPos}px`, width: `${sec.days * dayColWidth}px` }}
                                className={`absolute h-5 rounded flex items-center px-2 text-[10px] font-medium ${
                                  isModern
                                    ? 'bg-slate-700/50 text-slate-300 border border-slate-600/30'
                                    : 'bg-[#e2d8c9] text-black border border-[#baa990]'
                                }`}
                              >
                                <span>{sec.days}д</span>
                              </div>
                            </div>

                            {/* Task bars */}
                            {sec.tasks.map((task) => {
                              const taskLeft = (startIdx + task.startDay) * dayColWidth;
                              const taskWidth = task.durationDays * dayColWidth;

                              return (
                                <div key={task.id} className="h-7 flex items-center relative">
                                  <div
                                    onClick={() => setSelectedTask(task.id)}
                                    style={{ left: `${taskLeft}px`, width: `${taskWidth}px` }}
                                    className={`absolute h-5 rounded cursor-pointer flex items-center justify-between px-2 text-[10px] font-medium transition-transform hover:scale-[1.02] ${getOperationBadgeStyle(task.type)}`}
                                  >
                                    <span className="truncate">{task.name}</span>
                                    <span className="font-mono text-[9px] opacity-90">{task.durationDays}д</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Selected Task Inspector Drawer (Screenshot 9 detail) */}
      {selectedTask && (
        <div className={`px-4 py-2.5 border-t text-xs flex flex-wrap items-center justify-between gap-3 ${
          isModern 
            ? 'bg-[#151926] border-white/10 text-slate-300' 
            : 'bg-[#15120a] border-[#4d4022] text-[#e8d7a7]'
        }`}>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Люди:</span>
              <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-amber-500/15 text-amber-300 border border-amber-500/30">
                Иванов С. (Лазерная резка)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-400">Длительность:</span>
              <input 
                type="number" 
                defaultValue={2} 
                className={`w-12 px-2 py-0.5 rounded text-center font-mono ${
                  isModern 
                    ? 'bg-slate-800 text-white border border-white/10' 
                    : 'bg-black text-white border border-[#4d4022]'
                }`} 
              />
              <span className="text-slate-400">дней</span>
            </div>

            <span className="text-[11px] text-slate-400 hidden lg:inline">
              По умолчанию — только этот заказ (override). Цвет = вид работ.
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button className={`px-2.5 py-1 rounded text-xs font-medium ${
              isModern 
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold' 
                : 'bg-amber-400 text-black font-bold'
            }`}>
              Сохранить
            </button>
            <button 
              onClick={() => setSelectedTask(null)}
              className="text-slate-400 hover:text-white px-2 py-1"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
