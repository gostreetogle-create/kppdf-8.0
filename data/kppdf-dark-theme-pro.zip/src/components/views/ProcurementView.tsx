import React, { useState } from 'react';
import { 
  Plus, 
  RefreshCw, 
  ChevronDown, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  FileEdit, 
  Filter, 
  Check, 
  ShoppingBag, 
  ArrowRight
} from 'lucide-react';
import { ThemeStyle, AccentColor, ProcurementItem } from '../../types';
import { MOCK_PROCUREMENT } from '../../data/mockData';

interface ProcurementViewProps {
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const ProcurementView: React.FC<ProcurementViewProps> = ({ themeStyle, accent }) => {
  const isModern = themeStyle === 'modern';
  const [items, setItems] = useState<ProcurementItem[]>(MOCK_PROCUREMENT);
  const [expandedId, setExpandedId] = useState<string | null>('proc-1');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const toggleExpand = (id: string) => {
    setExpandedId(prev => prev === id ? null : id);
  };

  const getStatusBadge = (status: ProcurementItem['status']) => {
    if (!isModern) {
      // Legacy style from screenshot: plain text, dull amber or white
      switch (status) {
        case 'received': return <span className="text-white">Получено</span>;
        case 'confirmed': return <span className="text-amber-400">Подтверждено</span>;
        case 'draft': return <span className="text-white">Черновик</span>;
        case 'ordered': return <span className="text-blue-400">Заказано</span>;
      }
    }

    // Modern style: rich semantic badges with soft background, border, and indicator
    switch (status) {
      case 'received':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Получено
          </span>
        );
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-300 border border-amber-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            Подтверждено
          </span>
        );
      case 'ordered':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
            Заказано
          </span>
        );
      case 'draft':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-700/30 text-slate-400 border border-slate-700/50">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
            Черновик
          </span>
        );
    }
  };

  return (
    <div 
      id="procurement-view-container"
      className={`w-full flex-1 overflow-y-auto p-4 sm:p-6 select-none ${
        isModern ? 'bg-[#0c0e14] text-slate-200' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      <div className="max-w-6xl mx-auto space-y-5">
        {/* Header Title Section */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className={`text-[11px] font-mono uppercase tracking-wider font-semibold ${
              isModern ? 'text-amber-400/90' : 'text-[#888]'
            }`}>
              Снабжение
            </div>
            <h1 className={`text-2xl font-bold tracking-tight ${
              isModern ? 'text-white' : 'text-white'
            }`}>
              Закупки
            </h1>
            <p className={`text-xs mt-0.5 ${
              isModern ? 'text-slate-400' : 'text-[#aaa]'
            }`}>
              Реестр задач снабжения: подтверждение, заказ, получение.
            </p>
          </div>

          {/* Top CTA Button */}
          <button
            className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-bold transition-all shadow-sm ${
              isModern
                ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold shadow-amber-950/20'
                : 'bg-[#ffc83b] text-black hover:bg-[#e6b435]'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>ЗАДАЧА</span>
          </button>
        </div>

        {/* Toolbar: Filters & Refresh */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-3">
            <div className="relative">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className={`text-xs rounded px-3 py-1.5 pr-8 appearance-none focus:outline-none transition-colors ${
                  isModern
                    ? 'bg-[#181c2a] text-slate-200 border border-white/10 focus:border-amber-500'
                    : 'bg-black text-white border border-[#4d4022]'
                }`}
              >
                <option value="all">Все статусы</option>
                <option value="draft">Черновики</option>
                <option value="confirmed">Подтверждённые</option>
                <option value="received">Полученные</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>

            <span className={`text-xs ${isModern ? 'text-slate-400' : 'text-slate-400'}`}>
              <strong>{items.length}</strong> задач
            </span>
          </div>

          <button
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-xs transition-colors ${
              isModern
                ? 'bg-[#181c2a] hover:bg-slate-800 text-slate-300 border border-white/10'
                : 'bg-black text-white border border-[#4d4022] hover:bg-[#1a1a1a]'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>ОБНОВИТЬ</span>
          </button>
        </div>

        {/* Main Table Container */}
        <div className={`rounded-lg overflow-hidden border ${
          isModern 
            ? 'bg-[#131622] border-white/[0.08] shadow-xl shadow-black/30' 
            : 'bg-black border-[#4d4022]'
        }`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className={`border-b ${
                  isModern 
                    ? 'bg-[#181c2b] text-slate-400 border-white/[0.06]' 
                    : 'bg-black text-white border-[#4d4022]'
                }`}>
                  <th className="py-2.5 px-3 w-8"></th>
                  <th className="py-2.5 px-3 font-medium">Позиция</th>
                  <th className="py-2.5 px-3 font-medium">Заказ</th>
                  <th className="py-2.5 px-3 font-medium text-right">Кол-во</th>
                  <th className="py-2.5 px-3 font-medium">Статус</th>
                  <th className="py-2.5 px-3 font-medium">Создано</th>
                  <th className="py-2.5 px-3 font-medium text-right">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {items.map((item) => {
                  const isExpanded = expandedId === item.id;
                  return (
                    <React.Fragment key={item.id}>
                      <tr 
                        onClick={() => toggleExpand(item.id)}
                        className={`cursor-pointer transition-colors ${
                          isModern 
                            ? isExpanded ? 'bg-white/[0.04]' : 'hover:bg-white/[0.02]' 
                            : 'hover:bg-[#141414]'
                        }`}
                      >
                        <td className="py-3 px-3 text-slate-500">
                          {isExpanded ? (
                            <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                          ) : (
                            <ChevronRight className="w-3.5 h-3.5" />
                          )}
                        </td>
                        <td className="py-3 px-3 font-medium text-white">
                          {item.name}
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-300">
                          {item.orderId}
                        </td>
                        <td className="py-3 px-3 font-mono text-right text-slate-300">
                          {item.quantity} {item.unit}
                        </td>
                        <td className="py-3 px-3">
                          {getStatusBadge(item.status)}
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-400">
                          {item.createdDate}
                        </td>
                        <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            {item.status === 'confirmed' && (
                              <>
                                <button className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                                  isModern
                                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10'
                                    : 'bg-black text-white border border-[#4d4022]'
                                }`}>
                                  В черновик
                                </button>
                                <button className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                                  isModern
                                    ? 'bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40'
                                    : 'bg-black text-white border border-[#4d4022]'
                                }`}>
                                  Заказано
                                </button>
                              </>
                            )}

                            {item.status === 'draft' && (
                              <button className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                                isModern
                                  ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40'
                                  : 'bg-black text-white border border-[#4d4022]'
                              }`}>
                                Подтвердить
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>

                      {/* Expandable Detail View (Screenshot 8) */}
                      {isExpanded && (
                        <tr className={isModern ? 'bg-[#10131e]' : 'bg-[#0a0a0a]'}>
                          <td colSpan={7} className="p-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {/* Left Card: Позиция */}
                              <div className={`p-3.5 rounded border ${
                                isModern 
                                  ? 'bg-[#161a28] border-white/[0.08]' 
                                  : 'bg-black border-[#4d4022]'
                              }`}>
                                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                                  Позиция
                                </h4>
                                <div className="space-y-1.5 text-xs">
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Название:</span>
                                    <span className="text-slate-200 font-medium">{item.name}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Кол-во:</span>
                                    <span className="text-slate-200 font-mono">{item.quantity}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Статус:</span>
                                    <span>{getStatusBadge(item.status)}</span>
                                  </div>
                                </div>
                              </div>

                              {/* Right Card: Связь с заказом */}
                              <div className={`p-3.5 rounded border ${
                                isModern 
                                  ? 'bg-[#161a28] border-white/[0.08]' 
                                  : 'bg-black border-[#4d4022]'
                              }`}>
                                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                                  Связь с заказом
                                </h4>
                                <div className="space-y-2 text-xs">
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Линия заказа:</span>
                                    <span className="text-slate-400">—</span>
                                  </div>
                                  <div className="pt-1">
                                    <span className={`inline-block px-3 py-1 rounded font-mono font-bold text-xs ${
                                      isModern 
                                        ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30' 
                                        : 'bg-black text-amber-400 border border-[#4d4022]'
                                    }`}>
                                      Заказ {item.orderId}
                                    </span>
                                  </div>
                                </div>
                              </div>

                              {/* Bottom Left Card: Состав */}
                              <div className={`p-3.5 rounded border ${
                                isModern 
                                  ? 'bg-[#161a28] border-white/[0.08]' 
                                  : 'bg-black border-[#4d4022]'
                              }`}>
                                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                                  Состав
                                </h4>
                                <div className="space-y-1.5 text-xs">
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Материал:</span>
                                    <span className="text-slate-300">{item.materialType || 'Материал задан'}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Модуль:</span>
                                    <span className="text-slate-300">{item.module || 'Модуль задан'}</span>
                                  </div>
                                </div>
                              </div>

                              {/* Bottom Right Card: Сроки и заметки */}
                              <div className={`p-3.5 rounded border ${
                                isModern 
                                  ? 'bg-[#161a28] border-white/[0.08]' 
                                  : 'bg-black border-[#4d4022]'
                              }`}>
                                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                                  Сроки и заметки
                                </h4>
                                <div className="space-y-1 text-xs">
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Создано:</span>
                                    <span className="text-slate-300 font-mono">{item.createdDate}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Подтверждено:</span>
                                    <span className="text-slate-300 font-mono">{item.confirmedDate || '13.09.2026'}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-slate-500">Обновлено:</span>
                                    <span className="text-slate-300 font-mono">{item.updatedDate || '13.09.2026'}</span>
                                  </div>
                                  <div className="text-slate-500 italic pt-1">
                                    {item.notes || 'Без примечаний'}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
