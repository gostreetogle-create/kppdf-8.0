import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  ChevronDown, 
  SlidersHorizontal, 
  ArrowUpDown, 
  Package, 
  AlertTriangle,
  Layers,
  Edit2
} from 'lucide-react';
import { ThemeStyle, AccentColor, WarehouseItem } from '../../types';
import { MOCK_WAREHOUSE } from '../../data/mockData';

interface WarehouseViewProps {
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const WarehouseView: React.FC<WarehouseViewProps> = ({ themeStyle, accent }) => {
  const isModern = themeStyle === 'modern';
  const [subTab, setSubTab] = useState<'remains' | 'warehouses' | 'movements'>('remains');
  const [filterLowStock, setFilterLowStock] = useState(false);
  const [items, setItems] = useState<WarehouseItem[]>(MOCK_WAREHOUSE);

  const displayedItems = filterLowStock ? items.filter(i => i.status === 'Мало остатков' || i.quantity <= i.minimum) : items;

  return (
    <div 
      id="warehouse-view-container"
      className={`w-full flex-1 overflow-y-auto p-4 sm:p-6 select-none ${
        isModern ? 'bg-[#0c0e14] text-slate-200' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      <div className="max-w-6xl mx-auto space-y-5">
        {/* Sub-nav Tabs: Остатки, Склады, Движения */}
        <div className="flex items-center gap-1 border-b border-white/[0.08] pb-1">
          <button
            onClick={() => setSubTab('remains')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t transition-colors ${
              subTab === 'remains'
                ? isModern 
                  ? 'bg-[#181c2b] text-white border-b-2 border-amber-400' 
                  : 'bg-white text-black font-bold'
                : isModern 
                  ? 'text-slate-400 hover:text-slate-200' 
                  : 'text-[#888]'
            }`}
          >
            Остатки
          </button>
          <button
            onClick={() => setSubTab('warehouses')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t transition-colors ${
              subTab === 'warehouses'
                ? isModern 
                  ? 'bg-[#181c2b] text-white border-b-2 border-amber-400' 
                  : 'bg-white text-black font-bold'
                : isModern 
                  ? 'text-slate-400 hover:text-slate-200' 
                  : 'text-[#888]'
            }`}
          >
            Склады
          </button>
          <button
            onClick={() => setSubTab('movements')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t transition-colors ${
              subTab === 'movements'
                ? isModern 
                  ? 'bg-[#181c2b] text-white border-b-2 border-amber-400' 
                  : 'bg-white text-black font-bold'
                : isModern 
                  ? 'text-slate-400 hover:text-slate-200' 
                  : 'text-[#888]'
            }`}
          >
            Движения
          </button>
        </div>

        {/* Title & Top Action */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className={`text-[11px] font-mono uppercase tracking-wider font-semibold ${
              isModern ? 'text-amber-400/90' : 'text-[#888]'
            }`}>
              Склад
            </span>
            <h1 className="text-2xl font-bold tracking-tight text-white">Остатки</h1>
          </div>

          <button
            className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-bold transition-all shadow-sm ${
              isModern
                ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold'
                : 'bg-[#ffc83b] text-black hover:bg-[#e6b435]'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>ПОСТАВИТЬ НА СКЛАД</span>
          </button>
        </div>

        {/* Filters bar */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative">
            <select
              className={`text-xs rounded px-3 py-1.5 pr-8 appearance-none focus:outline-none ${
                isModern
                  ? 'bg-[#181c2a] text-slate-200 border border-white/10'
                  : 'bg-black text-white border border-[#4d4022]'
              }`}
            >
              <option>Все склады</option>
              <option>Главный склад</option>
              <option>Участок раскроя</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          </div>

          <label className="flex items-center gap-2 cursor-pointer text-xs">
            <input
              type="checkbox"
              checked={filterLowStock}
              onChange={(e) => setFilterLowStock(e.target.checked)}
              className="rounded accent-amber-500 w-3.5 h-3.5"
            />
            <span className={isModern ? 'text-slate-300' : 'text-slate-300'}>
              Мало остатков <span className="text-amber-400 font-mono">2 позиции</span>
            </span>
          </label>
        </div>

        {/* Table */}
        <div className={`rounded-lg overflow-hidden border ${
          isModern 
            ? 'bg-[#131622] border-white/[0.08] shadow-xl shadow-black/30' 
            : 'bg-black border-[#4d4022]'
        }`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className={`border-b ${
                  isModern 
                    ? 'bg-[#181c2b] text-slate-400 border-white/[0.06]' 
                    : 'bg-black text-white border-[#4d4022]'
                }`}>
                  <th className="py-2.5 px-4 font-medium">Продукт / Материал</th>
                  <th className="py-2.5 px-4 font-medium">Склад</th>
                  <th className="py-2.5 px-4 font-medium text-right">Количество</th>
                  <th className="py-2.5 px-4 font-medium text-right">Резерв</th>
                  <th className="py-2.5 px-4 font-medium text-right">Минимум</th>
                  <th className="py-2.5 px-4 font-medium text-center">Зона</th>
                  <th className="py-2.5 px-4 font-medium text-right">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {displayedItems.map((item) => (
                  <tr 
                    key={item.id}
                    className={`transition-colors ${
                      isModern ? 'hover:bg-white/[0.02]' : 'hover:bg-[#141414]'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{item.name}</div>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                        <span className="text-slate-500">{item.type}</span>
                        <span>•</span>
                        <span className="font-mono">{item.sku}</span>
                        <span>•</span>
                        <span>{item.unit}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {item.warehouse}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-white">
                      {item.quantity}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-400">
                      {item.reserved}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-400">
                      {item.minimum}
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-slate-300">
                      {item.zone}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                        isModern
                          ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10'
                          : 'bg-black text-white border border-[#4d4022]'
                      }`}>
                        КОРРЕКТИРОВАТЬ
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
