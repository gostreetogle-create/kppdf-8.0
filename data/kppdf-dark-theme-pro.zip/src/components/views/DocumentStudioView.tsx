import React, { useState } from 'react';
import { 
  Search, 
  ZoomIn, 
  ZoomOut, 
  Layers, 
  FileText, 
  Plus, 
  Sliders, 
  Edit3, 
  Share2, 
  Printer, 
  Download 
} from 'lucide-react';
import { ThemeStyle, AccentColor } from '../../types';
import { MOCK_STUDIO_PRODUCTS } from '../../data/mockData';

interface DocumentStudioViewProps {
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const DocumentStudioView: React.FC<DocumentStudioViewProps> = ({ themeStyle, accent }) => {
  const isModern = themeStyle === 'modern';
  const [activeTab, setActiveTab] = useState<'products' | 'client' | 'relations' | 'more'>('products');
  const [activeSubTab, setActiveSubTab] = useState<'items' | 'modules' | 'parts' | 'raw'>('items');
  const [search, setSearch] = useState('');
  const [zoom, setZoom] = useState(100);

  const filtered = MOCK_STUDIO_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div 
      id="document-studio-container"
      className={`w-full flex-1 flex overflow-hidden select-none ${
        isModern ? 'bg-[#0c0e14] text-slate-200' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      {/* Left Sidebar: Product & Elements Palette */}
      <div className={`w-80 sm:w-96 flex-shrink-0 flex flex-col border-r ${
        isModern ? 'bg-[#131622] border-white/[0.08]' : 'bg-black border-[#4d4022]'
      }`}>
        {/* Breadcrumb Header */}
        <div className={`px-4 py-3 border-b ${
          isModern ? 'bg-[#181c2b] border-white/[0.06]' : 'bg-black border-[#4d4022]'
        }`}>
          <div className="text-[11px] font-mono text-slate-400">
            <span>Документы</span> / <span>Студия</span> / <span className="text-amber-400 font-bold">КП</span>
          </div>
          <div className="text-xs font-bold uppercase tracking-wider text-white mt-1">
            ДАННЫЕ
          </div>
        </div>

        {/* Primary Tabs */}
        <div className="flex border-b border-white/[0.08]">
          {[
            { id: 'products', label: 'Товары' },
            { id: 'client', label: 'Кому' },
            { id: 'relations', label: 'Связи' },
            { id: 'more', label: 'Ещё' },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`flex-1 py-2 text-xs font-medium transition-colors ${
                activeTab === t.id
                  ? isModern
                    ? 'bg-[#1d2235] text-white border-b-2 border-amber-400 font-semibold'
                    : 'bg-white text-black font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Subtabs */}
        <div className={`grid grid-cols-4 p-1.5 border-b text-[11px] gap-1 ${
          isModern ? 'bg-[#11131c] border-white/[0.06]' : 'bg-[#0d0d0d] border-[#4d4022]'
        }`}>
          {[
            { id: 'items', label: 'Изделия' },
            { id: 'modules', label: 'Модули' },
            { id: 'parts', label: 'Детали' },
            { id: 'raw', label: 'Материалы' },
          ].map(st => (
            <button
              key={st.id}
              onClick={() => setActiveSubTab(st.id as any)}
              className={`py-1 rounded text-center transition-colors ${
                activeSubTab === st.id
                  ? isModern 
                    ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30' 
                    : 'bg-[#ffc83b] text-black font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="p-3 border-b border-white/[0.06]">
          <div className="relative">
            <input
              type="text"
              placeholder="Поиск по изделиям..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className={`w-full text-xs rounded px-3 py-1.5 pl-8 focus:outline-none ${
                isModern 
                  ? 'bg-[#1a1f2e] text-slate-200 border border-white/10 focus:border-amber-500' 
                  : 'bg-black text-white border border-[#4d4022]'
              }`}
            />
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
          </div>
        </div>

        {/* Product Cards List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filtered.map((product) => (
            <div
              key={product.id}
              className={`p-3 rounded-lg border transition-all ${
                isModern
                  ? 'bg-[#171b28] hover:bg-[#1c2132] border-white/[0.06] hover:border-white/15'
                  : 'bg-black border-[#4d4022] hover:bg-[#111]'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs font-semibold text-white">{product.name}</div>
                  <div className="text-[11px] font-mono text-slate-400 mt-0.5">{product.code}</div>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400">{product.price}</span>
              </div>

              <div className="flex items-center justify-end gap-1.5 mt-2.5 pt-2 border-t border-white/[0.05]">
                <button className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                  isModern
                    ? 'bg-white/5 hover:bg-white/10 text-slate-300'
                    : 'bg-black text-white border border-[#4d4022]'
                }`}>
                  Изменить
                </button>
                <button className={`px-2.5 py-0.5 rounded text-[11px] font-bold ${
                  isModern
                    ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30'
                    : 'bg-[#ffc83b] text-black font-semibold'
                }`}>
                  + Добавить
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Area: Document Sheet View Canvas */}
      <div className={`flex-1 flex flex-col overflow-hidden relative ${
        isModern ? 'bg-[#161a26]' : 'bg-black'
      }`}>
        {/* Canvas Toolbar */}
        <div className={`h-11 flex items-center justify-between px-4 border-b ${
          isModern ? 'bg-[#131622] border-white/[0.08]' : 'bg-black border-[#4d4022]'
        }`}>
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-300">Коммерческое предложение № 2026-44</span>
            <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20 font-mono">Черновик</span>
          </div>

          <div className="flex items-center gap-2">
            <button className={`p-1.5 rounded ${isModern ? 'hover:bg-white/10 text-slate-300' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
              <ZoomOut className="w-3.5 h-3.5" onClick={() => setZoom(Math.max(50, zoom - 10))} />
            </button>
            <span className="text-xs font-mono text-slate-300">{zoom}%</span>
            <button className={`p-1.5 rounded ${isModern ? 'hover:bg-white/10 text-slate-300' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
              <ZoomIn className="w-3.5 h-3.5" onClick={() => setZoom(Math.min(150, zoom + 10))} />
            </button>
            <span className="text-xs text-slate-500 ml-2 font-mono">1 / 2</span>
          </div>
        </div>

        {/* Paper Canvas */}
        <div className="flex-1 overflow-auto p-8 flex justify-center items-start">
          {/* Simulated A4 sheet */}
          <div 
            style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top center' }}
            className={`w-[595px] min-h-[842px] bg-white text-slate-900 p-10 transition-shadow ${
              isModern 
                ? 'rounded shadow-2xl shadow-black/80 ring-1 ring-white/10' 
                : 'shadow-none border border-[#4d4022]'
            }`}
          >
            {/* Header of proposal */}
            <div className="border-b-2 border-slate-900 pb-4 mb-6 flex justify-between items-end">
              <div>
                <h2 className="text-xl font-extrabold uppercase tracking-tight text-slate-900">КОММЕРЧЕСКОЕ ПРЕДЛОЖЕНИЕ</h2>
                <div className="text-xs text-slate-600 mt-1">Производственная компания «KPPDF СТУДИЯ»</div>
              </div>
              <div className="text-right text-xs font-mono text-slate-700">
                <div>№ КП-0926-08</div>
                <div>от 15.09.2026 г.</div>
              </div>
            </div>

            {/* Simulated Table */}
            <table className="w-full text-left text-xs border-collapse mb-6">
              <thead>
                <tr className="border-b border-slate-400 bg-slate-100">
                  <th className="p-2 font-bold text-slate-900">Наименование</th>
                  <th className="p-2 font-bold text-slate-900 text-center">Кол-во</th>
                  <th className="p-2 font-bold text-slate-900 text-center">Ед.</th>
                  <th className="p-2 font-bold text-slate-900 text-right">Цена, ₽</th>
                  <th className="p-2 font-bold text-slate-900 text-right">Сумма, ₽</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="p-2 font-medium">Стеллаж складской 2000×600×2500</td>
                  <td className="p-2 text-center font-mono">6</td>
                  <td className="p-2 text-center">шт</td>
                  <td className="p-2 text-right font-mono">12 400</td>
                  <td className="p-2 text-right font-mono font-bold">74 400</td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Ограждение лестницы «Ритм»</td>
                  <td className="p-2 text-center font-mono">2</td>
                  <td className="p-2 text-center">компл</td>
                  <td className="p-2 text-right font-mono">18 600</td>
                  <td className="p-2 text-right font-mono font-bold">37 200</td>
                </tr>
                <tr>
                  <td className="p-2 font-medium">Порошковая окраска RAL 7024</td>
                  <td className="p-2 text-center font-mono">1</td>
                  <td className="p-2 text-center">услуга</td>
                  <td className="p-2 text-right font-mono">14 000</td>
                  <td className="p-2 text-right font-mono font-bold">14 000</td>
                </tr>
              </tbody>
            </table>

            {/* Total */}
            <div className="flex justify-end mb-8">
              <div className="w-60 bg-slate-50 p-3 rounded border border-slate-200">
                <div className="flex justify-between text-xs text-slate-600">
                  <span>Подытог:</span>
                  <span className="font-mono font-medium">125 600 ₽</span>
                </div>
                <div className="flex justify-between text-xs text-slate-600 mt-1">
                  <span>НДС (20%):</span>
                  <span className="font-mono font-medium">25 120 ₽</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-900 mt-2 pt-2 border-t border-slate-300">
                  <span>Итого к оплате:</span>
                  <span className="font-mono text-emerald-800">150 720 ₽</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 border-t border-slate-200 pt-4">
              Срок изготовления: 14 рабочих дней с момента внесения предоплаты.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
