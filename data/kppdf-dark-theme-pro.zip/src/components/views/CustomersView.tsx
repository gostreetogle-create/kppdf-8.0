import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Phone, Building2, Search } from 'lucide-react';
import { ThemeStyle, AccentColor, CustomerItem } from '../../types';
import { MOCK_CUSTOMERS } from '../../data/mockData';

interface CustomersViewProps {
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const CustomersView: React.FC<CustomersViewProps> = ({ themeStyle, accent }) => {
  const isModern = themeStyle === 'modern';
  const [customers, setCustomers] = useState<CustomerItem[]>(MOCK_CUSTOMERS);
  const [search, setSearch] = useState('');

  const filtered = customers.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.inn.includes(search)
  );

  return (
    <div 
      id="customers-view-container"
      className={`w-full flex-1 overflow-y-auto p-4 sm:p-6 select-none ${
        isModern ? 'bg-[#0c0e14] text-slate-200' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      <div className="max-w-6xl mx-auto space-y-5">
        {/* Title and Add button */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className={`text-[11px] font-mono uppercase tracking-wider font-semibold ${
              isModern ? 'text-amber-400/90' : 'text-[#888]'
            }`}>
              Клиенты
            </span>
            <h1 className="text-2xl font-bold tracking-tight text-white">Заказчики</h1>
          </div>

          <button
            className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs font-bold transition-all shadow-sm ${
              isModern
                ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold'
                : 'bg-[#ffc83b] text-black hover:bg-[#e6b435]'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>СОЗДАТЬ ЗАКАЗЧИКА</span>
          </button>
        </div>

        {/* Search input */}
        <div className="max-w-md relative">
          <input
            type="text"
            placeholder="Поиск по названию или ИНН..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full text-xs rounded-lg px-3.5 py-2 pl-9 focus:outline-none transition-colors ${
              isModern
                ? 'bg-[#151926] text-slate-200 border border-white/10 focus:border-amber-500'
                : 'bg-black text-white border border-[#4d4022]'
            }`}
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Customers Table */}
        <div className={`rounded-lg overflow-hidden border ${
          isModern 
            ? 'bg-[#131622] border-white/[0.08] shadow-xl shadow-black/30' 
            : 'bg-black border-[#4d4022]'
        }`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className={`border-b ${
                  isModern 
                    ? 'bg-[#181c2b] text-slate-400 border-white/[0.06]' 
                    : 'bg-black text-white border-[#4d4022]'
                }`}>
                  <th className="py-2.5 px-4 font-medium">Название</th>
                  <th className="py-2.5 px-4 font-medium">ИНН</th>
                  <th className="py-2.5 px-4 font-medium">Контакт</th>
                  <th className="py-2.5 px-4 font-medium text-right">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {filtered.map((customer) => (
                  <tr 
                    key={customer.id}
                    className={`transition-colors ${
                      isModern ? 'hover:bg-white/[0.02]' : 'hover:bg-[#141414]'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{customer.name}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{customer.legalName}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      {customer.inn}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      {customer.phone}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button className={`p-1.5 rounded transition-colors ${
                          isModern
                            ? 'hover:bg-white/10 text-slate-400 hover:text-slate-200'
                            : 'border border-[#4d4022] text-[#c2b28f]'
                        }`}>
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button className={`p-1.5 rounded transition-colors ${
                          isModern
                            ? 'hover:bg-red-500/20 text-slate-400 hover:text-red-400'
                            : 'border border-[#4d4022] text-[#c2b28f]'
                        }`}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
