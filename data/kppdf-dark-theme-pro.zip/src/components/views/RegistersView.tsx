import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Plus, Search, Edit2, Copy, Trash2, BookOpen } from 'lucide-react';
import { ThemeStyle, AccentColor, CatalogItem } from '../../types';
import { MOCK_CATALOG } from '../../data/mockData';

interface RegistersViewProps {
  themeStyle: ThemeStyle;
  accent: AccentColor;
}

export const RegistersView: React.FC<RegistersViewProps> = ({ themeStyle, accent }) => {
  const isModern = themeStyle === 'modern';
  const [materialsExpanded, setMaterialsExpanded] = useState(true);
  const [catalog] = useState<CatalogItem[]>(MOCK_CATALOG);
  const [search, setSearch] = useState('');

  const filtered = catalog.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.sku.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div 
      id="registers-view-container"
      className={`w-full flex-1 overflow-y-auto p-4 sm:p-6 select-none ${
        isModern ? 'bg-[#0c0e14] text-slate-200' : 'bg-black text-[#e8d7a7]'
      }`}
    >
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Реестры</h1>
          <p className="text-xs text-slate-400 mt-0.5">Справочники, классификаторы и каталог номенклатуры</p>
        </div>

        {/* Section 1: Справочники */}
        <div className="space-y-3">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold">
            Справочники
          </div>

          <div className={`rounded-lg overflow-hidden border ${
            isModern ? 'bg-[#131622] border-white/[0.08]' : 'bg-black border-[#4d4022]'
          }`}>
            <div className="divide-y divide-white/[0.04] text-xs">
              {/* Единицы измерения */}
              <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] cursor-pointer">
                <div className="flex items-center gap-2.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                  <div>
                    <div className="font-semibold text-white">Единицы измерения</div>
                    <div className="text-[11px] text-slate-400">Справочник единиц измерения (GET /units, PATCH /units/:key)</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">API</span>
                  <span className="text-slate-400 font-mono">6 записей</span>
                </div>
              </div>

              {/* Категории */}
              <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] cursor-pointer">
                <div className="flex items-center gap-2.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                  <div>
                    <div className="font-semibold text-white">Категории</div>
                    <div className="text-[11px] text-slate-400">Категории деталей, изделий и модулей (Category API)</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">API</span>
                  <span className="text-slate-400 font-mono">8 записей</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Каталог */}
        <div className="space-y-3">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold">
            Каталог
          </div>

          <div className={`rounded-lg overflow-hidden border ${
            isModern ? 'bg-[#131622] border-white/[0.08]' : 'bg-black border-[#4d4022]'
          }`}>
            {/* Header / Accordion trigger */}
            <div 
              onClick={() => setMaterialsExpanded(!materialsExpanded)}
              className={`p-3.5 flex items-center justify-between cursor-pointer border-b ${
                isModern 
                  ? 'bg-[#181c2b] border-white/[0.06]' 
                  : 'bg-black border-[#4d4022]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {materialsExpanded ? <ChevronDown className="w-3.5 h-3.5 text-amber-400" /> : <ChevronRight className="w-3.5 h-3.5" />}
                <div>
                  <div className="font-bold text-white">Материалы</div>
                  <div className="text-[11px] text-slate-400">Сырьё и листовые материалы каталога (GET /materials, materialKind=raw)</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">API</span>
                <span className="text-slate-400 font-mono">9 записей</span>
              </div>
            </div>

            {/* Materials Table Content */}
            {materialsExpanded && (
              <div className="p-4 space-y-4">
                {/* Search / Filter Row */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      placeholder="Название, артикул, SKU..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className={`text-xs rounded px-3 py-1.5 w-60 focus:outline-none ${
                        isModern 
                          ? 'bg-[#1a1f2e] text-slate-200 border border-white/10 focus:border-amber-500' 
                          : 'bg-black text-white border border-[#4d4022]'
                      }`}
                    />
                    <select className={`text-xs rounded px-3 py-1.5 focus:outline-none ${
                      isModern 
                        ? 'bg-[#1a1f2e] text-slate-200 border border-white/10' 
                        : 'bg-black text-white border border-[#4d4022]'
                    }`}>
                      <option>ID из реестра «Категории»</option>
                      <option>Металлы</option>
                      <option>Крепёж</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <button className={`p-1.5 rounded ${
                      isModern 
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold' 
                        : 'bg-[#ffc83b] text-black'
                    }`}>
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs text-slate-400 font-mono">1–9 из 9</span>
                  </div>
                </div>

                {/* Table */}
                <div className="overflow-x-auto border border-white/[0.05] rounded">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className={`border-b ${
                        isModern ? 'bg-[#161a26] text-slate-400 border-white/[0.05]' : 'bg-black text-white border-[#4d4022]'
                      }`}>
                        <th className="py-2.5 px-3 font-medium">Название</th>
                        <th className="py-2.5 px-3 font-medium">Артикул</th>
                        <th className="py-2.5 px-3 font-medium">Внутр. код</th>
                        <th className="py-2.5 px-3 font-medium">Ед.</th>
                        <th className="py-2.5 px-3 font-medium">Категория</th>
                        <th className="py-2.5 px-3 font-medium">Марка</th>
                        <th className="py-2.5 px-3 font-medium text-right">Цена</th>
                        <th className="py-2.5 px-3 font-medium text-right">Действия</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.04]">
                      {filtered.map((item) => (
                        <tr key={item.id} className={`transition-colors ${isModern ? 'hover:bg-white/[0.02]' : 'hover:bg-[#141414]'}`}>
                          <td className="py-2.5 px-3 font-medium text-white">{item.name}</td>
                          <td className="py-2.5 px-3 font-mono text-slate-300">{item.sku}</td>
                          <td className="py-2.5 px-3 font-mono text-slate-400">{item.internalCode}</td>
                          <td className="py-2.5 px-3 text-slate-300">{item.unit}</td>
                          <td className="py-2.5 px-3 text-slate-400">{item.category}</td>
                          <td className="py-2.5 px-3 text-slate-300">{item.grade}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-semibold text-amber-400">{item.price.toLocaleString()} ₽</td>
                          <td className="py-2.5 px-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button className={`p-1 rounded ${isModern ? 'hover:bg-white/10 text-slate-400' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button className={`p-1 rounded ${isModern ? 'hover:bg-white/10 text-slate-400' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
                                <Copy className="w-3 h-3" />
                              </button>
                              <button className={`p-1 rounded ${isModern ? 'hover:bg-red-500/20 text-slate-400 hover:text-red-400' : 'border border-[#4d4022] text-[#c2b28f]'}`}>
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
