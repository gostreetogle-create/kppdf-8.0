import { GanttItem, ProcurementItem, WarehouseItem, CustomerItem, CatalogItem, WorkTypeItem } from '../types';

export const MOCK_WORK_TYPES: WorkTypeItem[] = [
  { id: 'wt-1', name: 'Резка металла', days: '', normHours: 8, orderIndex: 0 },
  { id: 'wt-2', name: 'Гибочные работы', days: '', normHours: 8, orderIndex: 1 },
  { id: 'wt-3', name: 'Сварочные работы', days: '', normHours: 12, orderIndex: 2 },
  { id: 'wt-4', name: 'Порошковая покраска', days: '', normHours: 6, orderIndex: 3 }
];

export const MOCK_GANTT_ORDERS: GanttItem[] = [
  {
    id: 'ord-1',
    orderNumber: 'ORD-2026-022',
    title: 'Металлоконструкции навеса 12x6м',
    status: 'В работе',
    priority: 'normal',
    startDate: '17.07.2026',
    totalDays: 14,
    isExpanded: false,
    sections: [
      {
        id: 'sec-1-1',
        title: 'Опорные колонны',
        days: 7,
        tasks: [
          { id: 't-1', name: 'Резка профильной трубы', type: 'cutting', startDay: 0, durationDays: 3, status: 'completed' },
          { id: 't-2', name: 'Сварка фланцев', type: 'welding', startDay: 3, durationDays: 2, status: 'in_progress' },
          { id: 't-3', name: 'Покраска грунтом', type: 'painting', startDay: 5, durationDays: 2, status: 'pending' }
        ]
      }
    ]
  },
  {
    id: 'ord-2',
    orderNumber: '3-2026-004',
    title: 'Ворота распашные 3000x2000 со створкой',
    status: 'Подтверждён',
    priority: 'normal',
    startDate: '19.07.2026',
    totalDays: 5,
    isExpanded: true,
    sections: [
      {
        id: 'sec-2-1',
        title: 'Ворота распашные 30...',
        days: 5,
        tasks: [
          { id: 't-4', name: 'Резка профильной трубы', type: 'cutting', startDay: 2, durationDays: 2, status: 'completed', assignedTo: 'Иванов С. (Лазерная)' }
        ]
      },
      {
        id: 'sec-2-2',
        title: 'Створка ворот',
        days: 5,
        tasks: [
          { id: 't-5', name: 'Покраска', type: 'painting', startDay: 2, durationDays: 3, status: 'in_progress', assignedTo: 'Морозов В. (Малярный)' },
          { id: 't-6', name: 'Резка металла', type: 'cutting', startDay: 5, durationDays: 2, status: 'pending' },
          { id: 't-7', name: 'Сварка', type: 'welding', startDay: 4, durationDays: 2, status: 'pending' }
        ]
      }
    ]
  },
  {
    id: 'ord-3',
    orderNumber: '3-2026-006',
    title: 'Стеллажная система тип 4А',
    status: 'Подтверждён',
    priority: 'normal',
    startDate: '23.07.2026',
    totalDays: 23,
    isExpanded: false
  },
  {
    id: 'ord-4',
    orderNumber: '3-2026-009',
    title: 'Фермы кровельные усиленные',
    status: 'Подтверждён',
    priority: 'urgent',
    startDate: '23.07.2026',
    totalDays: 34,
    isExpanded: false
  },
  {
    id: 'ord-5',
    orderNumber: '3-2026-002',
    title: 'Перила балконные кованые',
    status: 'В работе',
    priority: 'normal',
    startDate: '25.07.2026',
    totalDays: 16,
    isExpanded: false
  },
  {
    id: 'ord-6',
    orderNumber: '3-2026-008',
    title: 'Емкостное оборудование 5м3',
    status: 'Подтверждён',
    priority: 'normal',
    startDate: '25.07.2026',
    totalDays: 18,
    isExpanded: false
  },
  {
    id: 'ord-7',
    orderNumber: '3-2026-001',
    title: 'Пандус въездной для склада',
    status: 'Подтверждён',
    priority: 'normal',
    startDate: '27.07.2026',
    totalDays: 6,
    isExpanded: false
  },
  {
    id: 'ord-8',
    orderNumber: '3-2026-007',
    title: 'Ограждение лестницы «Ритм»',
    status: 'Подтверждён',
    priority: 'normal',
    startDate: '27.07.2026',
    totalDays: 18,
    isExpanded: true,
    sections: [
      {
        id: 'sec-8-1',
        title: 'Ограждение лестницы...',
        days: 18,
        tasks: [
          { id: 't-8-1', name: 'Резка металла', type: 'cutting', startDay: 6, durationDays: 3, status: 'completed' },
          { id: 't-8-2', name: 'Сварка ×14', type: 'welding', startDay: 9, durationDays: 2, status: 'in_progress' },
          { id: 't-8-3', name: 'Покраска ×14', type: 'painting', startDay: 9, durationDays: 3, status: 'pending' }
        ]
      },
      {
        id: 'sec-8-2',
        title: 'Поручень',
        days: 18,
        tasks: [
          { id: 't-8-4', name: 'Покраска ×14', type: 'painting', startDay: 6, durationDays: 3, status: 'completed' },
          { id: 't-8-5', name: 'Резка металла ...', type: 'cutting', startDay: 9, durationDays: 13, status: 'in_progress' },
          { id: 't-8-6', name: 'Гибочные рабо...', type: 'bending', startDay: 13, durationDays: 5, status: 'pending' }
        ]
      }
    ]
  }
];

export const MOCK_PROCUREMENT: ProcurementItem[] = [
  {
    id: 'proc-1',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 2,
    unit: 'компл',
    status: 'received',
    createdDate: '06.09.2026',
    confirmedDate: '13.09.2026',
    updatedDate: '13.09.2026',
    materialType: 'Материал задан',
    module: 'Модуль задан',
    notes: 'Без примечаний'
  },
  {
    id: 'proc-2',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 2,
    unit: 'шт',
    status: 'confirmed',
    createdDate: '06.09.2026',
    materialType: 'Лист стальной 2 мм',
    module: 'Стойка вертикальная'
  },
  {
    id: 'proc-3',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 7,
    unit: 'пог. м',
    status: 'draft',
    createdDate: '06.09.2026',
    materialType: 'Труба профильная 40х20х2'
  },
  {
    id: 'proc-4',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 3,
    unit: 'шт',
    status: 'draft',
    createdDate: '06.09.2026',
    materialType: 'Фланец крепления'
  },
  {
    id: 'proc-5',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 3,
    unit: 'шт',
    status: 'draft',
    createdDate: '06.09.2026'
  },
  {
    id: 'proc-6',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 5,
    unit: 'шт',
    status: 'draft',
    createdDate: '06.09.2026'
  },
  {
    id: 'proc-7',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 3,
    unit: 'шт',
    status: 'draft',
    createdDate: '06.09.2026'
  },
  {
    id: 'proc-8',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 5,
    unit: 'шт',
    status: 'draft',
    createdDate: '06.09.2026'
  },
  {
    id: 'proc-9',
    name: 'Материал из состава',
    orderId: '3-2026-006',
    quantity: 3,
    unit: 'шт',
    status: 'draft',
    createdDate: '06.09.2026'
  },
  {
    id: 'proc-10',
    name: 'СМОК материал mt4ai7dr',
    orderId: 'ORD-2026-022',
    quantity: 5,
    unit: 'шт',
    status: 'received',
    createdDate: '22.08.2026',
    confirmedDate: '24.08.2026'
  }
];

export const MOCK_WAREHOUSE: WarehouseItem[] = [
  {
    id: 'wh-1',
    name: 'СМОК материал mt4ai7dr',
    type: 'Материал',
    warehouse: 'Главный склад',
    quantity: 20,
    reserved: 0,
    minimum: 2,
    zone: 'A1',
    unit: 'шт',
    sku: 'SMK-MAT-mt4ai7dr',
    status: 'Активна'
  },
  {
    id: 'wh-2',
    name: 'СМОК изделие mt4ai7dr',
    type: 'Продукт',
    warehouse: 'Главный склад',
    quantity: 8,
    reserved: 0,
    minimum: 2,
    zone: '—',
    unit: 'шт',
    sku: 'SMK-PROD-mt4ai7dr',
    status: 'Активна'
  },
  {
    id: 'wh-3',
    name: 'Лист стальной 2 мм Ст3сп',
    type: 'Материал',
    warehouse: 'Участок раскроя',
    quantity: 3,
    reserved: 4,
    minimum: 10,
    zone: 'B-04',
    unit: 'м²',
    sku: 'MT-104',
    status: 'Мало остатков'
  },
  {
    id: 'wh-4',
    name: 'Труба профильная 40х20х2 мм',
    type: 'Материал',
    warehouse: 'Главный склад',
    quantity: 45,
    reserved: 12,
    minimum: 50,
    zone: 'C-12',
    unit: 'м',
    sku: 'MT-101',
    status: 'Мало остатков'
  }
];

export const MOCK_CUSTOMERS: CustomerItem[] = [
  { id: 'c-1', name: 'Торговая сеть „Формат“', legalName: 'АО «Торговая сеть „Формат“»', inn: '7700041020', phone: '+7 (495) 3012-12-12', city: 'Москва', ordersCount: 14 },
  { id: 'c-2', name: 'Кузнецова Е.С.', legalName: 'ИП Кузнецова Е.С.', inn: '7700041090', phone: '+7 (495) 3019-19-19', city: 'Подольск', ordersCount: 3 },
  { id: 'c-3', name: 'ГК „Берёзка“', legalName: 'ООО «ГК „Берёзка“»', inn: '7700041051', phone: '+7 (495) 3015-15-15', city: 'Химки', ordersCount: 8 },
  { id: 'c-4', name: 'Загородный Дом', legalName: 'ООО «Загородный Дом»', inn: '7700041012', phone: '+7 (495) 3011-11-11', city: 'Красногорск', ordersCount: 22 },
  { id: 'c-5', name: 'Кафе-Прованс', legalName: 'ООО «Кафе-Прованс»', inn: '7700041044', phone: '+7 (495) 3014-14-14', city: 'Москва', ordersCount: 5 },
  { id: 'c-6', name: 'Ландшафт-Парк', legalName: 'ООО «Ландшафт-Парк»', inn: '7700041037', phone: '+7 (495) 3013-13-13', city: 'Одинцово', ordersCount: 9 },
  { id: 'c-7', name: 'Магазин „У дома“', legalName: 'ООО «Магазин „У дома“»', inn: '7700041083', phone: '+7 (495) 3018-18-18', city: 'Мытищи', ordersCount: 7 },
  { id: 'c-8', name: 'Складские решения', legalName: 'ООО «Складские решения»', inn: '7700041069', phone: '+7 (495) 3016-16-16', city: 'Москва', ordersCount: 16 },
  { id: 'c-9', name: 'СтройГрад', legalName: 'ООО «СтройГрад»', inn: '7700041005', phone: '+7 (495) 3010-10-10', city: 'Балашиха', ordersCount: 11 },
  { id: 'c-10', name: 'Частный сектор 24', legalName: 'ООО «Частный сектор 24»', inn: '7700041076', phone: '+7 (495) 3017-17-17', city: 'Дмитров', ordersCount: 4 }
];

export const MOCK_CATALOG: CatalogItem[] = [
  { id: 'cat-1', sku: 'QA-LIST-001', internalCode: '—', name: 'QA Тестовый лист ст3', unit: 'sheet', category: '—', grade: '—', price: 0 },
  { id: 'cat-2', sku: 'MT-105', internalCode: 'MT-105', name: 'Лист оцинкованный 1,5 мм', unit: 'м²', category: '—', grade: '08пс', price: 1280 },
  { id: 'cat-3', sku: 'MT-104', internalCode: 'MT-104', name: 'Лист стальной 2 мм', unit: 'м²', category: 'Металлы', grade: 'Ст3сп', price: 1450 },
  { id: 'cat-4', sku: 'MT-107', internalCode: 'MT-107', name: 'Полоса стальная 25×4 мм', unit: 'м', category: '—', grade: 'Ст3сп', price: 90 },
  { id: 'cat-5', sku: 'MT-108', internalCode: 'MT-108', name: 'Пруток стальной Ø10 мм', unit: 'м', category: '—', grade: 'Ст3сп', price: 60 },
  { id: 'cat-6', sku: 'MT-103', internalCode: 'MT-103', name: 'Труба профильная 20×20×1,5 мм', unit: 'м', category: '—', grade: 'Ст3сп', price: 140 },
  { id: 'cat-7', sku: 'MT-101', internalCode: 'MT-101', name: 'Труба профильная 40×20×2 мм', unit: 'м', category: '—', grade: 'Ст3сп', price: 320 },
  { id: 'cat-8', sku: 'MT-102', internalCode: 'MT-102', name: 'Труба профильная 60×30×2 мм', unit: 'м', category: '—', grade: 'Ст3сп', price: 420 },
  { id: 'cat-9', sku: 'MT-106', internalCode: 'MT-106', name: 'Уголок стальной 40×40×3 мм', unit: 'м', category: '—', grade: 'Ст3сп', price: 260 }
];

export const MOCK_STUDIO_PRODUCTS = [
  { id: 'sp-1', name: 'WS-СМОК изделие 2 mu2x5s1e', code: 'WS-SMK-2-mu2x5s1e', price: '4 800 ₽', category: 'Изделия' },
  { id: 'sp-2', name: 'WS-СМОК изделие 1 mu2x5s1e', code: 'WS-SMK-1-mu2x5s1e', price: '3 900 ₽', category: 'Изделия' },
  { id: 'sp-3', name: 'WS-СМОК изделие 2 mu2x4oip', code: 'WS-SMK-2-mu2x4oip', price: '5 200 ₽', category: 'Изделия' },
  { id: 'sp-4', name: 'WS-СМОК изделие 1 mu2x4oip', code: 'WS-SMK-1-mu2x4oip', price: '4 400 ₽', category: 'Изделия' },
  { id: 'sp-5', name: 'WS-СМОК изделие 2 mu2wy6gz', code: 'WS-SMK-2-mu2wy6gz', price: '6 100 ₽', category: 'Изделия' },
  { id: 'sp-6', name: 'WS-СМОК изделие 1 mu2wy6gz', code: 'WS-SMK-1-mu2wy6gz', price: '5 500 ₽', category: 'Изделия' },
  { id: 'sp-7', name: '021', code: '356', price: '1 200 ₽', category: 'Изделия' },
  { id: 'sp-8', name: 'СМОК изделие mt4ai7dr', code: 'SMK-PROD-mt4ai7dr', price: '8 500 ₽', category: 'Изделия' },
  { id: 'sp-9', name: 'Мангал с крышей «Очаг»', code: '4010', price: '14 200 ₽', category: 'Изделия' },
  { id: 'sp-10', name: 'Козырёк над входом «Капля»', code: '4009', price: '9 800 ₽', category: 'Изделия' },
  { id: 'sp-11', name: 'Стеллаж складской 2000×600×2500', code: '4008', price: '12 400 ₽', category: 'Изделия' },
  { id: 'sp-12', name: 'Ограждение лестницы «Ритм»', code: '4007', price: '18 600 ₽', category: 'Изделия' },
  { id: 'sp-13', name: 'Навес «Волна» 4000×6000', code: '4006', price: '54 000 ₽', category: 'Изделия' }
];
