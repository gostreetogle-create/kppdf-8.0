export type MainTab = 
  | 'clients' 
  | 'deals' 
  | 'procurement' 
  | 'workshop' 
  | 'warehouse' 
  | 'documents' 
  | 'registers' 
  | 'admin';

export type ThemeStyle = 'modern' | 'legacy';

export type AccentColor = 'amber' | 'blue' | 'emerald' | 'cyan';

export interface WorkTypeItem {
  id: string;
  name: string;
  days: number | string;
  normHours: number;
  orderIndex: number;
}

export interface GanttSubTask {
  id: string;
  name: string;
  type: 'cutting' | 'welding' | 'painting' | 'bending' | 'assembly';
  startDay: number;
  durationDays: number;
  status: 'pending' | 'in_progress' | 'completed';
  assignedTo?: string;
  normHours?: number;
}

export interface GanttItem {
  id: string;
  orderNumber: string;
  title: string;
  status: string;
  priority: 'normal' | 'high' | 'urgent';
  startDate: string;
  totalDays: number;
  isExpanded?: boolean;
  sections?: {
    id: string;
    title: string;
    days: number;
    tasks: GanttSubTask[];
  }[];
}

export interface ProcurementItem {
  id: string;
  name: string;
  orderId: string;
  quantity: number;
  unit: string;
  status: 'received' | 'confirmed' | 'draft' | 'ordered';
  createdDate: string;
  confirmedDate?: string;
  updatedDate?: string;
  materialType?: string;
  module?: string;
  notes?: string;
}

export interface WarehouseItem {
  id: string;
  name: string;
  type: 'Материал' | 'Продукт' | 'Деталь';
  warehouse: string;
  quantity: number;
  reserved: number;
  minimum: number;
  zone: string;
  unit: string;
  sku: string;
  status: 'Активна' | 'Мало остатков' | 'Архив';
}

export interface CustomerItem {
  id: string;
  name: string;
  legalName: string;
  inn: string;
  phone: string;
  city?: string;
  ordersCount?: number;
}

export interface CatalogItem {
  id: string;
  sku: string;
  internalCode: string;
  name: string;
  unit: string;
  category: string;
  grade: string;
  sortament?: string;
  price: number;
}
