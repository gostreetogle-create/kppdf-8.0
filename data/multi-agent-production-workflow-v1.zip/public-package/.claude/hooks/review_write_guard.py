"""Fail-closed Claude Code hook for a public multi-agent template.

Reviewer mode may write only review artifacts. Executor mode is enabled by an
existing `.project-review/agent-task.md` marker prepared by the integrator and
may write only exact `allowed_paths`. Bash is limited to read-only commands or
exact commands declared in the active marker.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import sys
from pathlib import Path


PROJECT_ROOT = Path(os.environ.get("CLAUDE_PROJECT_DIR", ".")).resolve()
MARKER = PROJECT_ROOT / ".project-review" / "agent-task.md"
REVIEW_FILES = {
    ".project-review/recommendations.md",
    ".project-review/review-log.md",
}
RECOMMENDATION_RE = re.compile(r"^\.project-review/recommendations_REV-\d{3,4}\.md$")
READ_ONLY_PREFIXES = (
    "git status",
    "git diff",
    "git log",
    "git show",
    "git blame",
    "git branch --show-current",
    "git worktree list",
)
DANGEROUS_PARTS = (
    "git push",
    "git reset --hard",
    "git clean",
    "git merge",
    "git rebase",
    "rm -rf",
    "del /s",
    "remove-item -recurse",
    "docker compose down",
    "docker system prune",
    "alembic upgrade",
    "alembic downgrade",
    "ssh ",
    "scp ",
    "rsync ",
)
SHELL_META = (";", "&&", "||", "`", "$(", ">", "<")


def parse_marker() -> dict[str, str]:
    if not MARKER.is_file():
        return {"status": "inactive"}
    values: dict[str, str] = {}
    for raw in MARKER.read_text(encoding="utf-8").splitlines():
        if not raw or raw.lstrip().startswith("#") or ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        values[key.strip().lower()] = value.strip()
    return values


def split_pipe(value: str) -> set[str]:
    return {item.strip() for item in value.split("|") if item.strip()}


def split_csv(value: str) -> set[str]:
    return {item.strip().replace("\\", "/") for item in value.split(",") if item.strip()}


def relative_path(raw_path: str) -> str | None:
    path = Path(raw_path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    try:
        return path.resolve().relative_to(PROJECT_ROOT).as_posix()
    except (OSError, ValueError):
        return None


def evaluate_write(raw_path: str) -> tuple[bool, str]:
    relative = relative_path(raw_path)
    if relative is None:
        return False, "target is outside the project root"

    marker = parse_marker()
    status = marker.get("status", "inactive").lower()
    agent = marker.get("agent", "").lower()

    if status == "inactive":
        if relative in REVIEW_FILES or RECOMMENDATION_RE.fullmatch(relative):
            return True, "review artifact"
        return False, "reviewer may write only review artifacts"

    if status not in {"active", "completed"} or agent != "claude":
        return False, "invalid or non-Claude executor marker"

    allowed = split_csv(marker.get("allowed_paths", ""))
    allowed.add(".project-review/agent-task.md")
    if relative not in allowed:
        return False, f"executor write outside allowed_paths: {relative}"
    return True, "bounded executor path"


def evaluate_bash(command: str) -> tuple[bool, str]:
    normalized = " ".join(command.strip().split())
    lowered = normalized.lower()
    if any(meta in command for meta in SHELL_META):
        return False, "shell chaining, substitution and redirection are blocked"
    if any(part in lowered for part in DANGEROUS_PARTS):
        return False, "dangerous command is blocked"

    marker = parse_marker()
    status = marker.get("status", "inactive").lower()
    if any(lowered.startswith(prefix) for prefix in READ_ONLY_PREFIXES):
        return True, "approved read-only command"

    if status == "active" and marker.get("agent", "").lower() == "claude":
        allowed = split_pipe(marker.get("allowed_commands", ""))
        if normalized in allowed:
            return True, "exact executor command"

    if status == "completed" and marker.get("agent", "").lower() == "claude":
        commit_command = marker.get("commit_command", "").strip()
        if commit_command and normalized == commit_command:
            return True, "exact scoped commit command"

    return False, "Bash command is not explicitly allowed"


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        sys.stderr.write("Multi-agent guard: invalid payload; action blocked.\n")
        return 2

    tool_input = payload.get("tool_input") or {}
    command = tool_input.get("command")
    if command is not None:
        allowed, reason = evaluate_bash(str(command))
    else:
        raw_path = tool_input.get("file_path") or tool_input.get("filePath") or tool_input.get("path")
        if not raw_path:
            allowed, reason = False, "target path is missing"
        else:
            allowed, reason = evaluate_write(str(raw_path))

    if allowed:
        return 0
    sys.stderr.write(f"Multi-agent guard blocked the action: {reason}\n")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
