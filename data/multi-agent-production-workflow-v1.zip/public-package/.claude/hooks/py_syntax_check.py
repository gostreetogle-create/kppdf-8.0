"""Post-edit syntax check for Python files without project or DB side effects."""

import json
import py_compile
import sys
import tempfile
from pathlib import Path


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        return 0

    tool_input = payload.get("tool_input") or {}
    tool_response = payload.get("tool_response") or {}
    raw_path = tool_response.get("filePath") or tool_input.get("file_path")
    if not raw_path:
        return 0

    path = Path(raw_path)
    if path.suffix.lower() != ".py" or not path.is_file():
        return 0

    with tempfile.TemporaryDirectory() as tmp:
        cfile = str(Path(tmp) / "check.pyc")
        try:
            py_compile.compile(str(path), cfile=cfile, doraise=True)
        except py_compile.PyCompileError as exc:
            sys.stderr.write(f"Syntax check failed for {path}:\n{exc.msg}\n")
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
